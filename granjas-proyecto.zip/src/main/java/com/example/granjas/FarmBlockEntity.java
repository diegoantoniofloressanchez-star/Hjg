package com.example.granjas;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.NonNullList;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Cerebro de la granja: recibe los materiales (los huecos se vacian solos hacia un "banco" interno),
 * y cuando estan completos y el jugador acepta, construye el schematic por filas.
 */
public class FarmBlockEntity extends BlockEntity implements Container, MenuProvider {
    public static final int SIZE = 18;

    private final NonNullList<ItemStack> items = NonNullList.withSize(SIZE, ItemStack.EMPTY);
    /** Materiales ya entregados: id de item -> cantidad. */
    private final Map<String, Integer> bank = new HashMap<>();
    private boolean built = false;
    private boolean building = false;
    private int buildCursor = 0;

    public FarmBlockEntity(BlockPos pos, BlockState state) {
        super(ModRegistry.FARM_BE.get(), pos, state);
    }

    public FarmKind kind() {
        return getBlockState().getBlock() instanceof FarmBlock fb ? fb.kind() : FarmKind.SUGAR_CANE_FARM;
    }

    public boolean isBuilt() {
        return built;
    }

    // ------------------------------------------------------------- Guardado

    @Override
    public void saveAdditional(ValueOutput output) {
        super.saveAdditional(output);
        output.putBoolean("Built", built);
        output.putBoolean("Building", building);
        output.putInt("BuildCursor", buildCursor);
        ValueOutput.ValueOutputList bankList = output.childrenList("Bank");
        for (Map.Entry<String, Integer> e : bank.entrySet()) {
            ValueOutput child = bankList.addChild();
            child.putString("Id", e.getKey());
            child.putInt("N", e.getValue());
        }
        ValueOutput.ValueOutputList list = output.childrenList("Items");
        for (int i = 0; i < SIZE; i++) {
            ItemStack s = items.get(i);
            if (!s.isEmpty()) {
                ValueOutput child = list.addChild();
                child.putInt("Slot", i);
                child.store("Item", ItemStack.CODEC, s);
            }
        }
    }

    @Override
    public void loadAdditional(ValueInput input) {
        super.loadAdditional(input);
        built = input.getBooleanOr("Built", false);
        building = input.getBooleanOr("Building", false);
        buildCursor = input.getIntOr("BuildCursor", 0);
        bank.clear();
        for (ValueInput child : input.childrenListOrEmpty("Bank")) {
            String id = child.getStringOr("Id", "");
            int n = child.getIntOr("N", 0);
            if (!id.isEmpty() && n > 0) bank.put(id, n);
        }
        for (int i = 0; i < SIZE; i++) items.set(i, ItemStack.EMPTY);
        for (ValueInput child : input.childrenListOrEmpty("Items")) {
            int slot = child.getIntOr("Slot", -1);
            if (slot >= 0 && slot < SIZE) {
                child.read("Item", ItemStack.CODEC).ifPresent(s -> items.set(slot, s));
            }
        }
    }

    // ------------------------------------------------------------ Container

    @Override
    public int getContainerSize() {
        return SIZE;
    }

    @Override
    public boolean isEmpty() {
        for (ItemStack s : items) if (!s.isEmpty()) return false;
        return true;
    }

    @Override
    public ItemStack getItem(int slot) {
        return items.get(slot);
    }

    @Override
    public ItemStack removeItem(int slot, int amount) {
        ItemStack r = ContainerHelper.removeItem(items, slot, amount);
        if (!r.isEmpty()) setChanged();
        return r;
    }

    @Override
    public ItemStack removeItemNoUpdate(int slot) {
        return ContainerHelper.takeItem(items, slot);
    }

    @Override
    public void setItem(int slot, ItemStack stack) {
        items.set(slot, stack);
        setChanged();
    }

    @Override
    public boolean stillValid(Player player) {
        return level != null && level.getBlockEntity(worldPosition) == this
                && player.distanceToSqr(Vec3.atCenterOf(worldPosition)) <= 64.0;
    }

    @Override
    public void clearContent() {
        for (int i = 0; i < SIZE; i++) items.set(i, ItemStack.EMPTY);
    }

    @Override
    public boolean canPlaceItem(int slot, ItemStack stack) {
        return acceptsMaterial(stack);
    }

    @Override
    public boolean canTakeItem(Container target, int slot, ItemStack stack) {
        return false;
    }

    public boolean acceptsMaterial(ItemStack stack) {
        if (built || building) return false;
        for (FarmKind.Cost c : kind().cost()) {
            if (stack.is(c.item())) return true;
        }
        return false;
    }

    // ----------------------------------------------------------------- Banco

    private static String keyOf(Item item) {
        return BuiltInRegistries.ITEM.getKey(item).toString();
    }

    public int bankCount(Item item) {
        Integer n = bank.get(keyOf(item));
        return n == null ? 0 : n;
    }

    /** Entregado (banco + huecos). */
    public int count(Item item) {
        int total = bankCount(item);
        for (int i = 0; i < SIZE; i++) {
            ItemStack s = items.get(i);
            if (s.is(item)) total += s.getCount();
        }
        return total;
    }

    public boolean isComplete() {
        if (built || building) return false;
        List<FarmKind.Cost> cost = kind().cost();
        if (cost.isEmpty()) return false;
        for (FarmKind.Cost c : cost) {
            if (count(c.item()) < c.count()) return false;
        }
        return true;
    }

    public boolean canBuild(Player player) {
        if (built || building || kind().schematic() == null) return false;
        return player.isCreative() || isComplete();
    }

    /** Pasa los materiales de los huecos al banco (asi caben miles de items). */
    private void absorb() {
        boolean changed = false;
        for (FarmKind.Cost c : kind().cost()) {
            int need = c.count() - bankCount(c.item());
            if (need <= 0) continue;
            for (int i = 0; i < SIZE && need > 0; i++) {
                ItemStack s = items.get(i);
                if (s.is(c.item())) {
                    int n = Math.min(need, s.getCount());
                    s.shrink(n);
                    need -= n;
                    bank.merge(keyOf(c.item()), n, Integer::sum);
                    changed = true;
                    if (s.isEmpty()) items.set(i, ItemStack.EMPTY);
                }
            }
        }
        if (changed) setChanged();
    }

    private void consumeMaterials() {
        for (FarmKind.Cost c : kind().cost()) {
            String key = keyOf(c.item());
            int left = c.count() - bank.getOrDefault(key, 0);
            if (bank.getOrDefault(key, 0) <= c.count()) {
                bank.remove(key);
            } else {
                bank.put(key, bank.get(key) - c.count());
            }
            for (int i = 0; i < SIZE && left > 0; i++) {
                ItemStack s = items.get(i);
                if (s.is(c.item())) {
                    int n = Math.min(left, s.getCount());
                    s.shrink(n);
                    left -= n;
                    if (s.isEmpty()) items.set(i, ItemStack.EMPTY);
                }
            }
        }
    }

    /** Datos que se mandan al cliente: por cada material, la cantidad entregada en dos partes de 15 bits. */
    public ContainerData bankData() {
        return new ContainerData() {
            @Override
            public int get(int index) {
                List<FarmKind.Cost> cost = kind().cost();
                int req = index / 2;
                if (req >= cost.size()) return 0;
                int n = bankCount(cost.get(req).item());
                return index % 2 == 0 ? (n & 0x7FFF) : (n >> 15);
            }

            @Override
            public void set(int index, int value) {}

            @Override
            public int getCount() {
                return kind().cost().size() * 2;
            }
        };
    }

    // ----------------------------------------------------------------- Menus

    @Override
    public Component getDisplayName() {
        return getBlockState().getBlock().getName();
    }

    @Override
    public AbstractContainerMenu createMenu(int id, Inventory inv, Player player) {
        return new FarmMenu(id, inv, this);
    }

    private void writeHeader(RegistryFriendlyByteBuf buf) {
        buf.writeBlockPos(worldPosition);
        buf.writeVarInt(kind().ordinal());
    }

    public void openMain(ServerPlayer player) {
        if (building) {
            player.displayClientMessage(
                    Component.translatable("message.granjas.building", percent()).withStyle(ChatFormatting.YELLOW), true);
            return;
        }
        if (built) {
            player.displayClientMessage(
                    Component.translatable("message.granjas.built_already").withStyle(ChatFormatting.GREEN), true);
            return;
        }
        if (kind().schematic() == null) {
            player.displayClientMessage(
                    Component.translatable("message.granjas.no_schematic").withStyle(ChatFormatting.RED), true);
            return;
        }
        player.openMenu(this, this::writeHeader);
    }

    public void openConfirm(ServerPlayer player) {
        player.openMenu(
                new SimpleMenuProvider((id, inv, p) -> new FarmConfirmMenu(id, inv, this), getDisplayName()),
                this::writeHeader);
    }

    /** El jugador pulso ACEPTAR en la pantalla de confirmacion: consume y empieza a construir. */
    public void acceptBuild(ServerPlayer player) {
        FarmKind k = kind();
        if (!(level instanceof ServerLevel sl) || !canBuild(player)) {
            player.closeContainer();
            return;
        }
        if (!FarmBuilder.fitsHeight(sl, worldPosition, k)) {
            player.displayClientMessage(Component.translatable("message.granjas.height").withStyle(ChatFormatting.RED), true);
            openMain(player);
            return;
        }
        if (!FarmBuilder.isAreaSafe(sl, worldPosition, k)) {
            player.displayClientMessage(Component.translatable("message.granjas.blocked").withStyle(ChatFormatting.RED), true);
            openMain(player);
            return;
        }
        if (!player.isCreative()) consumeMaterials();
        building = true;
        buildCursor = 0;
        setChanged();
        player.closeContainer();
        player.displayClientMessage(
                Component.translatable("message.granjas.started", k.displayName()).withStyle(ChatFormatting.GREEN), true);
    }

    // ------------------------------------------------------------------ Tick

    public static void tick(Level level, BlockPos pos, BlockState state, FarmBlockEntity be) {
        if (level.isClientSide() || !(level instanceof ServerLevel sl)) return;
        long t = level.getGameTime();
        if (be.building) {
            be.buildStep(sl);
        } else if (!be.built && t % 2 == 0) {
            be.absorb();
        }
        if (!be.building && t % 20 == 0
                && sl.getNearestPlayer(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 48.0, false) != null) {
            FarmBuilder.showOutlines(sl, pos, be.kind(), be.built);
        }
        if (t % 10 == 0) be.showHud(sl);
    }

    private int percent() {
        int total = FarmBuilder.totalCells(kind());
        if (total <= 0) return 0;
        return (int) Math.min(100L, buildCursor * 100L / total);
    }

    /** Capa por capa hacia arriba, fila por fila. */
    private void buildStep(ServerLevel sl) {
        FarmKind k = kind();
        int total = FarmBuilder.totalCells(k);
        buildCursor = FarmBuilder.buildStep(sl, worldPosition, k, buildCursor, FarmBuilder.cellsPerTick(k));
        if (buildCursor >= total) {
            built = true;
            building = false;
            buildCursor = 0;
            Vec3 center = Vec3.atCenterOf(worldPosition);
            for (ServerPlayer p : sl.players()) {
                if (p.distanceToSqr(center) < 128.0 * 128.0) {
                    p.displayClientMessage(
                            Component.translatable("message.granjas.done", k.displayName()).withStyle(ChatFormatting.GREEN), true);
                }
            }
        }
        setChanged();
    }

    // ------------------------------------------------------- Info arriba (HUD)

    private void showHud(ServerLevel sl) {
        Vec3 center = Vec3.atCenterOf(worldPosition);
        for (ServerPlayer p : sl.players()) {
            if (p.distanceToSqr(center) > 64.0) continue;
            Vec3 eye = p.getEyePosition();
            Vec3 end = eye.add(p.getLookAngle().scale(6.0));
            BlockHitResult hit = sl.clip(new ClipContext(eye, end, ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, p));
            if (hit.getType() == HitResult.Type.BLOCK && hit.getBlockPos().equals(worldPosition)) {
                p.displayClientMessage(buildHud(), true);
            }
        }
    }

    private Component buildHud() {
        FarmKind k = kind();
        MutableComponent c = k.displayName().copy().withStyle(ChatFormatting.GOLD);
        c.append(Component.literal(" | ").withStyle(ChatFormatting.DARK_GRAY));
        if (building) {
            c.append(Component.translatable("hud.granjas.building", percent()).withStyle(ChatFormatting.YELLOW));
        } else if (built) {
            c.append(Component.translatable("hud.granjas.done").withStyle(ChatFormatting.GREEN));
        } else if (isComplete()) {
            c.append(Component.translatable("hud.granjas.ready").withStyle(ChatFormatting.GREEN));
        } else {
            List<FarmKind.Cost> missing = new ArrayList<>();
            for (FarmKind.Cost need : k.cost()) {
                if (count(need.item()) < need.count()) missing.add(need);
            }
            for (int i = 0; i < missing.size() && i < 3; i++) {
                FarmKind.Cost need = missing.get(i);
                if (i > 0) c.append(Component.literal(", ").withStyle(ChatFormatting.GRAY));
                MutableComponent line = Component.empty();
                line.append(need.icon().getHoverName());
                line.append(Component.literal(" " + Math.min(count(need.item()), need.count()) + "/" + need.count()));
                c.append(line.withStyle(ChatFormatting.RED));
            }
            if (missing.size() > 3) {
                c.append(Component.literal(" +" + (missing.size() - 3)).withStyle(ChatFormatting.GRAY));
            }
        }
        return c;
    }
}
