package com.example.granjas;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.zip.GZIPInputStream;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;

/**
 * Un schematic real convertido a nuestro formato (carpeta granjas_schematics del jar).
 * Orden de las celdas: (y * sz + z) * sx + x.
 */
public final class FarmSchematic {
    private static final Map<String, FarmSchematic> CACHE = new HashMap<>();
    private static final Set<String> FAILED = new HashSet<>();

    public final int sx;
    public final int sy;
    public final int sz;
    private final String[] paletteNames;
    private final short[] cells;
    private final List<FarmKind.Cost> requirements;
    private final BlockState[][] rotated = new BlockState[4][];

    private FarmSchematic(int sx, int sy, int sz, String[] paletteNames, short[] cells, List<FarmKind.Cost> requirements) {
        this.sx = sx;
        this.sy = sy;
        this.sz = sz;
        this.paletteNames = paletteNames;
        this.cells = cells;
        this.requirements = requirements;
    }

    /** Devuelve el schematic, o null si no se pudo cargar (entonces la granja se genera por codigo). */
    public static synchronized FarmSchematic get(String id) {
        FarmSchematic s = CACHE.get(id);
        if (s != null) return s;
        if (FAILED.contains(id)) return null;
        try {
            s = load(id);
            CACHE.put(id, s);
            return s;
        } catch (IOException | RuntimeException e) {
            FAILED.add(id);
            return null;
        }
    }

    private static FarmSchematic load(String id) throws IOException {
        try (InputStream raw = FarmSchematic.class.getResourceAsStream("/granjas_schematics/" + id + ".bin")) {
            if (raw == null) throw new IOException("no existe " + id);
            DataInputStream in = new DataInputStream(new BufferedInputStream(new GZIPInputStream(raw)));
            if (in.readInt() != 0x47534348) throw new IOException("formato invalido");
            in.readUnsignedShort(); // version
            int sx = in.readUnsignedShort();
            int sy = in.readUnsignedShort();
            int sz = in.readUnsignedShort();
            int paletteCount = in.readUnsignedShort();
            String[] palette = new String[paletteCount];
            for (int i = 0; i < paletteCount; i++) palette[i] = in.readUTF();
            int reqCount = in.readUnsignedShort();
            List<FarmKind.Cost> req = new ArrayList<>();
            for (int i = 0; i < reqCount; i++) {
                String itemId = in.readUTF();
                int count = in.readInt();
                Optional<Item> item = BuiltInRegistries.ITEM.getOptional(ResourceLocation.parse(itemId));
                if (item.isPresent() && item.get() != Items.AIR && count > 0) {
                    req.add(new FarmKind.Cost(item.get(), count));
                }
            }
            int runs = in.readInt();
            short[] cells = new short[sx * sy * sz];
            int pos = 0;
            for (int r = 0; r < runs; r++) {
                int len = readVarInt(in);
                short idx = (short) in.readUnsignedShort();
                for (int k = 0; k < len; k++) cells[pos++] = idx;
            }
            return new FarmSchematic(sx, sy, sz, palette, cells, req);
        }
    }

    private static int readVarInt(DataInputStream in) throws IOException {
        int v = 0;
        int shift = 0;
        while (true) {
            int b = in.readUnsignedByte();
            v |= (b & 0x7F) << shift;
            if ((b & 0x80) == 0) return v;
            shift += 7;
        }
    }

    public int cellCount() {
        return cells.length;
    }

    /** Indice de paleta de la celda i. */
    public int cell(int i) {
        return cells[i] & 0xFFFF;
    }

    /** Materiales necesarios para construirlo (ya mapeados a items). */
    public List<FarmKind.Cost> requirements() {
        return requirements;
    }

    /** Estados de bloque de la paleta, ya girados. */
    public BlockState[] states(Rotation rot) {
        BlockState[] arr = rotated[rot.ordinal()];
        if (arr == null) {
            arr = new BlockState[paletteNames.length];
            for (int i = 0; i < arr.length; i++) {
                arr[i] = parseState(paletteNames[i]).rotate(rot);
            }
            rotated[rot.ordinal()] = arr;
        }
        return arr;
    }

    // ----------------------------------------------------- "minecraft:bloque[prop=valor,...]"

    private static BlockState parseState(String text) {
        String name = text;
        String props = null;
        int br = text.indexOf('[');
        if (br >= 0) {
            name = text.substring(0, br);
            props = text.substring(br + 1, text.length() - 1);
        }
        Block block = BuiltInRegistries.BLOCK.getOptional(ResourceLocation.parse(name)).orElse(Blocks.AIR);
        BlockState state = block.defaultBlockState();
        if (props != null && !props.isEmpty()) {
            for (String kv : props.split(",")) {
                int eq = kv.indexOf('=');
                if (eq < 0) continue;
                Property<?> property = block.getStateDefinition().getProperty(kv.substring(0, eq));
                if (property != null) state = withValue(state, property, kv.substring(eq + 1));
            }
        }
        return state;
    }

    private static <T extends Comparable<T>> BlockState withValue(BlockState state, Property<T> property, String value) {
        Optional<T> parsed = property.getValue(value);
        return parsed.isPresent() ? state.setValue(property, parsed.get()) : state;
    }
}
