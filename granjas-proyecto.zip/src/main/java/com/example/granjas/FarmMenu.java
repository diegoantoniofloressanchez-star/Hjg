package com.example.granjas;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

/** Menu principal: 18 huecos de materiales + 18 de produccion + inventario del jugador. */
public class FarmMenu extends AbstractContainerMenu {
    public final BlockPos pos;
    public final FarmKind kind;
    public final int tier;
    private final FarmBlockEntity be; // solo en el servidor

    // Cliente
    public FarmMenu(int id, Inventory inv, RegistryFriendlyByteBuf buf) {
        this(id, inv, new SimpleContainer(FarmBlockEntity.SIZE), buf.readBlockPos(),
                FarmKind.values()[buf.readVarInt()], buf.readVarInt(), null);
    }

    // Servidor
    public FarmMenu(int id, Inventory inv, FarmBlockEntity be) {
        this(id, inv, be, be.getBlockPos(), be.kind(), be.tier(), be);
    }

    private FarmMenu(int id, Inventory inv, Container container, BlockPos pos, FarmKind kind, int tier, FarmBlockEntity be) {
        super(ModRegistry.FARM_MENU.get(), id);
        this.pos = pos;
        this.kind = kind;
        this.tier = tier;
        this.be = be;

        for (int r = 0; r < 2; r++) {
            for (int c = 0; c < 9; c++) {
                addSlot(new InputSlot(container, r * 9 + c, 8 + c * 18, 28 + r * 18));
            }
        }
        for (int r = 0; r < 2; r++) {
            for (int c = 0; c < 9; c++) {
                addSlot(new OutputSlot(container, FarmBlockEntity.IN + r * 9 + c, 8 + c * 18, 76 + r * 18));
            }
        }
        addStandardInventorySlots(inv, 8, 126);
    }

    private boolean accepts(ItemStack stack) {
        if (tier >= FarmKind.MAX_TIER) return false;
        for (FarmKind.Cost c : kind.cost(tier + 1)) {
            if (stack.is(c.item())) return true;
        }
        return false;
    }

    private class InputSlot extends Slot {
        InputSlot(Container container, int index, int x, int y) {
            super(container, index, x, y);
        }

        @Override
        public boolean mayPlace(ItemStack stack) {
            return accepts(stack);
        }
    }

    private static class OutputSlot extends Slot {
        OutputSlot(Container container, int index, int x, int y) {
            super(container, index, x, y);
        }

        @Override
        public boolean mayPlace(ItemStack stack) {
            return false;
        }
    }

    /** Boton 0: "construir" -> abre la pantalla de confirmacion si los materiales estan completos. */
    @Override
    public boolean clickMenuButton(Player player, int buttonId) {
        if (buttonId == 0 && be != null && player instanceof ServerPlayer sp) {
            if (be.isComplete()) be.openConfirm(sp);
            return true;
        }
        return false;
    }

    @Override
    public boolean stillValid(Player player) {
        return be == null || be.stillValid(player);
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        ItemStack result = ItemStack.EMPTY;
        Slot slot = this.slots.get(index);
        if (slot != null && slot.hasItem()) {
            ItemStack stack = slot.getItem();
            result = stack.copy();
            int total = this.slots.size(); // 72
            if (index < FarmBlockEntity.SIZE) {
                // De la granja al inventario del jugador
                if (!this.moveItemStackTo(stack, FarmBlockEntity.SIZE, total, true)) return ItemStack.EMPTY;
            } else {
                // Del inventario a los huecos de materiales
                if (!this.moveItemStackTo(stack, 0, FarmBlockEntity.IN, false)) return ItemStack.EMPTY;
            }
            if (stack.isEmpty()) {
                slot.setByPlayer(ItemStack.EMPTY);
            } else {
                slot.setChanged();
            }
            if (stack.getCount() == result.getCount()) return ItemStack.EMPTY;
            slot.onTake(player, stack);
        }
        return result;
    }
}
