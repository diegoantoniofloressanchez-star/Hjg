package com.example.granjas;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

/** Menu: 18 huecos donde pones materiales (se pasan solos al banco) + inventario del jugador. */
public class FarmMenu extends AbstractContainerMenu {
    public final BlockPos pos;
    public final FarmKind kind;
    /** Cantidades ya entregadas de cada material (2 datos por material). */
    public final ContainerData data;
    private final FarmBlockEntity be; // solo en el servidor

    private record Header(BlockPos pos, FarmKind kind) {}

    private static Header readHeader(RegistryFriendlyByteBuf buf) {
        BlockPos p = buf.readBlockPos();
        FarmKind k = FarmKind.values()[buf.readVarInt()];
        return new Header(p, k);
    }

    // Cliente
    public FarmMenu(int id, Inventory inv, RegistryFriendlyByteBuf buf) {
        this(id, inv, readHeader(buf));
    }

    private FarmMenu(int id, Inventory inv, Header h) {
        this(id, inv, new SimpleContainer(FarmBlockEntity.SIZE), h.pos(), h.kind(), null,
                new SimpleContainerData(h.kind().cost().size() * 2));
    }

    // Servidor
    public FarmMenu(int id, Inventory inv, FarmBlockEntity be) {
        this(id, inv, be, be.getBlockPos(), be.kind(), be, be.bankData());
    }

    private FarmMenu(int id, Inventory inv, Container container, BlockPos pos, FarmKind kind, FarmBlockEntity be,
                     ContainerData data) {
        super(ModRegistry.FARM_MENU.get(), id);
        this.pos = pos;
        this.kind = kind;
        this.be = be;
        this.data = data;

        for (int r = 0; r < 2; r++) {
            for (int c = 0; c < 9; c++) {
                addSlot(new InputSlot(container, r * 9 + c, 8 + c * 18, 28 + r * 18));
            }
        }
        addStandardInventorySlots(inv, 8, 108);
        addDataSlots(data);
    }

    /** Cantidad entregada del material numero 'index' de la lista. */
    public int bankOf(int index) {
        return (data.get(index * 2 + 1) << 15) | data.get(index * 2);
    }

    private boolean accepts(ItemStack stack) {
        for (FarmKind.Cost c : kind.cost()) {
            if (stack.is(c.item())) return true;
        }
        return false;
    }

    private class InputSlot extends Slot {
        InputSlot(Container container, int index, int x, int y) {
            super(container, index, x, y);
        }

        @Override
        public boolean mayPlace(ItemStack stack) {
            return accepts(stack);
        }
    }

    /** Boton 0: "construir" -> abre la pantalla de confirmacion si los materiales estan completos. */
    @Override
    public boolean clickMenuButton(Player player, int buttonId) {
        if (buttonId == 0 && be != null && player instanceof ServerPlayer sp) {
            if (be.canBuild(player)) be.openConfirm(sp);
            return true;
        }
        return false;
    }

    @Override
    public boolean stillValid(Player player) {
        return be == null || be.stillValid(player);
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        ItemStack result = ItemStack.EMPTY;
        Slot slot = this.slots.get(index);
        if (slot != null && slot.hasItem()) {
            ItemStack stack = slot.getItem();
            result = stack.copy();
            int total = this.slots.size();
            if (index < FarmBlockEntity.SIZE) {
                if (!this.moveItemStackTo(stack, FarmBlockEntity.SIZE, total, true)) return ItemStack.EMPTY;
            } else {
                if (!this.moveItemStackTo(stack, 0, FarmBlockEntity.SIZE, false)) return ItemStack.EMPTY;
            }
            if (stack.isEmpty()) {
                slot.setByPlayer(ItemStack.EMPTY);
            } else {
                slot.setChanged();
            }
            if (stack.getCount() == result.getCount()) return ItemStack.EMPTY;
            slot.onTake(player, stack);
        }
        return result;
    }
}
