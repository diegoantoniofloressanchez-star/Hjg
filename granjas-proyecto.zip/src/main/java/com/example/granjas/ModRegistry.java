package com.example.granjas;

import java.util.EnumMap;
import java.util.Map;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModRegistry {
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(GranjasMod.MOD_ID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(GranjasMod.MOD_ID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, GranjasMod.MOD_ID);
    public static final DeferredRegister<MenuType<?>> MENUS = DeferredRegister.create(Registries.MENU, GranjasMod.MOD_ID);
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, GranjasMod.MOD_ID);

    public static final Map<FarmKind, DeferredBlock<Block>> FARM_BLOCKS = new EnumMap<>(FarmKind.class);
    public static final Map<FarmKind, DeferredItem<BlockItem>> FARM_ITEMS = new EnumMap<>(FarmKind.class);

    static {
        for (FarmKind kind : FarmKind.values()) {
            DeferredBlock<Block> block = BLOCKS.registerBlock(kind.id, props -> new FarmBlock(props, kind),
                    BlockBehaviour.Properties.of().mapColor(MapColor.WOOD).strength(2.0F).sound(SoundType.WOOD));
            FARM_BLOCKS.put(kind, block);
            FARM_ITEMS.put(kind, ITEMS.registerSimpleBlockItem(kind.id, block));
        }
    }

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<FarmBlockEntity>> FARM_BE =
            BLOCK_ENTITIES.register("farm", () -> new BlockEntityType<>(FarmBlockEntity::new, false,
                    FARM_BLOCKS.values().stream().map(DeferredBlock::get).toArray(Block[]::new)));

    public static final DeferredHolder<MenuType<?>, MenuType<FarmMenu>> FARM_MENU =
            MENUS.register("farm", () -> IMenuTypeExtension.<FarmMenu>create(FarmMenu::new));

    public static final DeferredHolder<MenuType<?>, MenuType<FarmConfirmMenu>> FARM_CONFIRM_MENU =
            MENUS.register("farm_confirm", () -> IMenuTypeExtension.<FarmConfirmMenu>create(FarmConfirmMenu::new));

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> TAB = TABS.register("granjas",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.granjas"))
                    .icon(() -> new ItemStack(FARM_ITEMS.get(FarmKind.SUGAR_CANE_FARM).get()))
                    .displayItems((params, output) -> FARM_ITEMS.values().forEach(i -> output.accept(i.get())))
                    .build());
}
