package com.example.granjas;

import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/** Las 6 granjas del mod. Cada una se construye desde un schematic real. */
public enum FarmKind {
    SUGAR_CANE_FARM("sugar_cane_farm", "sugar_cane", "sugar_cane"),
    BAMBOO_FARM("bamboo_farm", "bamboo", "bamboo"),
    CACTUS_FARM("cactus_farm", "cactus", "cactus"),
    IRON_GOLEM_FARM("iron_golem_farm", "iron", "golem"),
    MOB_FARM("mob_farm", "mob", "skeleton"),
    CREEPER_FARM("creeper_farm", "creeper", "creeper");

    /** Un material requerido. */
    public record Cost(Item item, int count) {
        public ItemStack icon() {
            return new ItemStack(item);
        }
    }

    public final String id;
    private final String schematicId;
    /** Pixel art que se construye enfrente. */
    public final String artKey;

    FarmKind(String id, String schematicId, String artKey) {
        this.id = id;
        this.schematicId = schematicId;
        this.artKey = artKey;
    }

    public Component displayName() {
        return Component.translatable("block." + GranjasMod.MOD_ID + "." + id);
    }

    /** El schematic real de esta granja (null si no se pudo cargar). */
    public FarmSchematic schematic() {
        return FarmSchematic.get(schematicId);
    }

    /** Materiales necesarios para construirla. */
    public List<Cost> cost() {
        FarmSchematic s = schematic();
        return s == null ? List.of() : s.requirements();
    }

    /** Clave del aviso de lo que hay que poner a mano (aldeanos, vagonetas...). */
    public String entityNoteKey() {
        switch (this) {
            case IRON_GOLEM_FARM:
                return "iron";
            case SUGAR_CANE_FARM:
                return "sugar_cane";
            case CREEPER_FARM:
                return "creeper";
            default:
                return null;
        }
    }
}
