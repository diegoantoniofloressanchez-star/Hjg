package com.example.granjas;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * Todas las granjas del mod. Aqui estan los COSTOS por nivel, la VELOCIDAD y los DROPS.
 * Ajusta los numeros a tu gusto.
 */
public enum FarmKind {
    // ---- Recursos ----
    SUGAR_CANE_FARM("sugar_cane_farm", Theme.SUGAR_CANE, false),
    BAMBOO_FARM("bamboo_farm", Theme.BAMBOO, false),
    CACTUS_FARM("cactus_farm", Theme.CACTUS, false),
    PUMPKIN_FARM("pumpkin_farm", Theme.PUMPKIN, false),
    MELON_FARM("melon_farm", Theme.MELON, false),
    // ---- Mobs naturales ----
    ZOMBIE_FARM("zombie_farm", Theme.ZOMBIE, false),
    SKELETON_FARM("skeleton_farm", Theme.SKELETON, false),
    SPIDER_FARM("spider_farm", Theme.SPIDER, false),
    CREEPER_FARM("creeper_farm", Theme.CREEPER, false),
    // ---- Mobs con spawner (caras y mas rapidas) ----
    ZOMBIE_SPAWNER_FARM("zombie_spawner_farm", Theme.ZOMBIE, true),
    SKELETON_SPAWNER_FARM("skeleton_spawner_farm", Theme.SKELETON, true),
    SPIDER_SPAWNER_FARM("spider_spawner_farm", Theme.SPIDER, true),
    CREEPER_SPAWNER_FARM("creeper_spawner_farm", Theme.CREEPER, true);

    public static final int MAX_TIER = 3;

    public enum Theme {
        SUGAR_CANE, BAMBOO, CACTUS, PUMPKIN, MELON, ZOMBIE, SKELETON, SPIDER, CREEPER;

        public boolean isMob() {
            return ordinal() >= ZOMBIE.ordinal();
        }
    }

    /** Un material requerido. */
    public record Cost(Item item, int count) {
        public ItemStack icon() {
            return new ItemStack(item);
        }
    }

    /** Un drop de produccion. */
    public record Drop(Item item, int min, int max, float chance) {}

    public final String id;
    public final Theme theme;
    public final boolean spawner;

    FarmKind(String id, Theme theme, boolean spawner) {
        this.id = id;
        this.theme = theme;
        this.spawner = spawner;
    }

    public Component displayName() {
        return Component.translatable("block." + GranjasMod.MOD_ID + "." + id);
    }

    private static Cost c(Item item, int n) {
        return new Cost(item, n);
    }

    // ------------------------------------------------------------------ COSTOS

    /** Materiales para CONSTRUIR/MEJORAR hasta el nivel indicado (1..3). */
    public List<Cost> cost(int tier) {
        if (tier < 1 || tier > MAX_TIER) return List.of();

        if (!theme.isMob()) {
            Item sig = resourceItem();
            return switch (tier) {
                case 1 -> List.of(c(baseBlock(), 64), c(sig, 16), c(Items.IRON_INGOT, 4));
                case 2 -> List.of(c(sig, 32), c(Items.IRON_INGOT, 16), c(Items.REDSTONE, 32), c(Items.GLASS, 16));
                default -> List.of(c(sig, 64), c(Items.GOLD_INGOT, 16), c(Items.DIAMOND, 6), c(Items.REDSTONE_BLOCK, 4));
            };
        }

        Item drop = mobDrop();
        if (!spawner) {
            return switch (tier) {
                case 1 -> List.of(c(Items.STONE_BRICKS, 64), c(drop, 32), c(Items.IRON_INGOT, 8));
                case 2 -> List.of(c(Items.DEEPSLATE_BRICKS, 64), c(drop, 64), c(Items.IRON_INGOT, 16), c(Items.REDSTONE, 32));
                default -> List.of(c(Items.POLISHED_BLACKSTONE_BRICKS, 64), c(drop, 128), c(Items.GOLD_INGOT, 16),
                        c(Items.DIAMOND, 8), c(Items.REDSTONE_BLOCK, 4));
            };
        }

        // Spawner: caro de verdad (diamantes, estrella del Nether, cabezas...)
        return switch (tier) {
            case 1 -> List.of(c(Items.STONE_BRICKS, 64), c(Items.IRON_BARS, 16), c(drop, 64), mobHeadCost(),
                    c(Items.DIAMOND, 8), c(Items.NETHER_STAR, 1));
            case 2 -> List.of(c(Items.DEEPSLATE_BRICKS, 64), c(Items.IRON_BLOCK, 8), c(drop, 128),
                    c(Items.DIAMOND, 16), c(Items.GOLD_BLOCK, 4), c(Items.NETHER_STAR, 1));
            default -> List.of(c(Items.POLISHED_BLACKSTONE_BRICKS, 64), c(drop, 256), c(Items.DIAMOND_BLOCK, 4),
                    c(Items.NETHERITE_INGOT, 2), c(Items.NETHER_STAR, 2));
        };
    }

    private Item resourceItem() {
        return switch (theme) {
            case SUGAR_CANE -> Items.SUGAR_CANE;
            case BAMBOO -> Items.BAMBOO;
            case CACTUS -> Items.CACTUS;
            case PUMPKIN -> Items.PUMPKIN;
            case MELON -> Items.MELON_SLICE;
            default -> Items.AIR;
        };
    }

    private Item baseBlock() {
        return switch (theme) {
            case SUGAR_CANE, CACTUS -> Items.SAND;
            case BAMBOO -> Items.PODZOL;
            default -> Items.DIRT;
        };
    }

    private Item mobDrop() {
        return switch (theme) {
            case ZOMBIE -> Items.ROTTEN_FLESH;
            case SKELETON -> Items.BONE;
            case SPIDER -> Items.STRING;
            case CREEPER -> Items.GUNPOWDER;
            default -> Items.AIR;
        };
    }

    private Cost mobHeadCost() {
        return switch (theme) {
            case ZOMBIE -> c(Items.ZOMBIE_HEAD, 1);
            case SKELETON -> c(Items.SKELETON_SKULL, 1);
            case CREEPER -> c(Items.CREEPER_HEAD, 1);
            default -> c(Items.FERMENTED_SPIDER_EYE, 8); // la arana no tiene cabeza
        };
    }

    // ------------------------------------------------------------ PRODUCCION

    /** Ticks entre cada ciclo de produccion. */
    public int interval(int tier) {
        int[] t = !theme.isMob() ? new int[] {100, 70, 40}
                : spawner ? new int[] {80, 50, 30}
                : new int[] {200, 140, 100};
        return t[Math.max(1, Math.min(tier, MAX_TIER)) - 1];
    }

    /** Multiplicador de cantidad por ciclo. */
    public int multiplier(int tier) {
        int[] t = spawner ? new int[] {2, 3, 5} : new int[] {1, 2, 3};
        return t[Math.max(1, Math.min(tier, MAX_TIER)) - 1];
    }

    private List<Drop> drops() {
        return switch (theme) {
            case SUGAR_CANE -> List.of(new Drop(Items.SUGAR_CANE, 2, 4, 1f));
            case BAMBOO -> List.of(new Drop(Items.BAMBOO, 3, 6, 1f));
            case CACTUS -> List.of(new Drop(Items.CACTUS, 2, 4, 1f));
            case PUMPKIN -> List.of(new Drop(Items.PUMPKIN, 1, 2, 1f));
            case MELON -> List.of(new Drop(Items.MELON_SLICE, 3, 7, 1f));
            case ZOMBIE -> List.of(new Drop(Items.ROTTEN_FLESH, 0, 2, 1f), new Drop(Items.IRON_INGOT, 1, 1, 0.025f),
                    new Drop(Items.CARROT, 1, 1, 0.025f), new Drop(Items.POTATO, 1, 1, 0.025f));
            case SKELETON -> List.of(new Drop(Items.BONE, 0, 2, 1f), new Drop(Items.ARROW, 0, 2, 1f));
            case SPIDER -> List.of(new Drop(Items.STRING, 0, 2, 1f), new Drop(Items.SPIDER_EYE, 1, 1, 0.33f));
            case CREEPER -> List.of(new Drop(Items.GUNPOWDER, 0, 2, 1f));
        };
    }

    public List<ItemStack> rollDrops(int tier, RandomSource rnd) {
        List<ItemStack> out = new ArrayList<>();
        int mult = multiplier(tier);
        for (Drop d : drops()) {
            if (rnd.nextFloat() > d.chance()) continue;
            int n = (d.min() + rnd.nextInt(d.max() - d.min() + 1)) * mult;
            if (n > 0) out.add(new ItemStack(d.item(), n));
        }
        return out;
    }
}
