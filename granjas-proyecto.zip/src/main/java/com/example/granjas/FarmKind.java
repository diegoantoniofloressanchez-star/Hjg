package com.example.granjas;

import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/**
 * Los bloques del mod. Cada uno se construye desde un schematic real:
 * 6 granjas (redstone de verdad) y 20 construcciones decorativas.
 */
public enum FarmKind {
    // ---- Granjas ----
    SUGAR_CANE_FARM("sugar_cane_farm", "sugar_cane", "sugar_cane", false),
    BAMBOO_FARM("bamboo_farm", "bamboo", "bamboo", false),
    CACTUS_FARM("cactus_farm", "cactus", "cactus", false),
    IRON_GOLEM_FARM("iron_golem_farm", "iron", "golem", false),
    MOB_FARM("mob_farm", "mob", "skeleton", false),
    CREEPER_FARM("creeper_farm", "creeper", "creeper", false),
    // ---- Construcciones ----
    PISTON_DOOR_BUILD("piston_door_build", "piston_door", null, true),
    ADVENTURE_HOUSE_BUILD("adventure_house_build", "adventure_house", null, true),
    FARMER_HOUSE_BUILD("farmer_house_build", "farmer_house", null, true),
    KITTY_ART_BUILD("kitty_art_build", "kitty_art", null, true),
    KUROMI_ART_BUILD("kuromi_art_build", "kuromi_art", null, true),
    PIKACHU_ART_BUILD("pikachu_art_build", "pikachu_art", null, true),
    JAPANESE_TEMPLE_BUILD("japanese_temple_build", "japanese_temple", null, true),
    DRAGON_EGG_BUILD("dragon_egg_build", "dragon_egg", null, true),
    DRAGON_BUILD("dragon_build", "dragon", null, true),
    DUNGEON_BUILD("dungeon_build", "dungeon", null, true),
    ELDRITCH_EYE_BUILD("eldritch_eye_build", "eldritch_eye", null, true),
    ENDERMAN_STATUE_BUILD("enderman_statue_build", "enderman_statue", null, true),
    AXOLOTL_HOUSE_BUILD("axolotl_house_build", "axolotl_house", null, true),
    HOLLOW_KNIGHT_BUILD("hollow_knight_build", "hollow_knight", null, true),
    HOT_AIR_BALLOON_BUILD("hot_air_balloon_build", "hot_air_balloon", null, true),
    BIG_DECORATION_BUILD("big_decoration_build", "big_decoration", null, true),
    MACAW_STATUE_BUILD("macaw_statue_build", "macaw_statue", null, true),
    BEE_STATUE_BUILD("bee_statue_build", "bee_statue", null, true),
    NETHER_PORTAL_BUILD("nether_portal_build", "nether_portal", null, true),
    TOTEM_STATUE_BUILD("totem_statue_build", "totem_statue", null, true);

    /** Un material requerido. */
    public record Cost(Item item, int count) {
        public ItemStack icon() {
            return new ItemStack(item);
        }
    }

    public final String id;
    private final String schematicId;
    /** Pixel art que se construye enfrente (solo las granjas). */
    public final String artKey;
    private final boolean build;

    FarmKind(String id, String schematicId, String artKey, boolean build) {
        this.id = id;
        this.schematicId = schematicId;
        this.artKey = artKey;
        this.build = build;
    }

    /** true = construccion decorativa; false = granja real. */
    public boolean isBuild() {
        return build;
    }

    public Component displayName() {
        return Component.translatable("block." + GranjasMod.MOD_ID + "." + id);
    }

    /** El schematic real (null si no se pudo cargar). */
    public FarmSchematic schematic() {
        return FarmSchematic.get(schematicId);
    }

    /** Materiales necesarios para construirla. */
    public List<Cost> cost() {
        FarmSchematic s = schematic();
        return s == null ? List.of() : s.requirements();
    }

    public String realKey() {
        return build ? "gui.granjas.schem_build" : "gui.granjas.schem_real";
    }

    public String dimsKey() {
        return build ? "guide.granjas.dims_build" : "guide.granjas.schem_dims";
    }

    /** Clave del aviso de lo que hay que poner a mano (aldeanos, vagonetas...). */
    public String entityNoteKey() {
        switch (this) {
            case IRON_GOLEM_FARM:
                return "iron";
            case SUGAR_CANE_FARM:
                return "sugar_cane";
            case CREEPER_FARM:
                return "creeper";
            default:
                return null;
        }
    }
}
