package com.example.granjas;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/** Pixel art 9x9 de cada granja (se construye enfrente) + paleta de bloques. ARCHIVO GENERADO. */
public final class FarmArt {
    private FarmArt() {}

    public static String[] get(String key) {
        switch (key) {
            case "sugar_cane": return new String[] {".n..n..n.", ".u..u..u.", "nn..n..nn", ".n..n..n.", ".u..u..u.", ".n..n..n.", ".n..n..n.", ".u..u..u.", ".n..n..n."};
            case "bamboo": return new String[] {"..u...u..", "..n...n..", "..n...n..", ".uuu.uuu.", "..n...n..", "..n...n..", ".uuu.uuu.", "..n...n..", "..n...n.."};
            case "cactus": return new String[] {"....n....", "..n.n....", "..n.n.n..", "..nnn.n..", "....nnn..", "....n....", "....n....", "....n....", "...ttt..."};
            case "golem": return new String[] {".........", "..lllll..", ".lwwwwwl.", ".lwIIIIg.", ".lIIIIIg.", "..gIIIgg.", "...ggggg.", ".........", "........."};
            case "skeleton": return new String[] {".wwwwwww.", "wwwwwwwww", "wwwwwwwww", "w..www..w", "w..www..w", "wwwwwwwww", ".wwg.gww.", ".wwwwwww.", "..w.w.w.."};
            case "creeper": return new String[] {"nnnnnnnnn", "nnnnnnnnn", "n..nnn..n", "n..nnn..n", "nnnn.nnnn", "nnn...nnn", "nnn...nnn", "nnn.n.nnn", "nnnnnnnnn"};
            default: return new String[] {".........", ".........", ".........", ".........", ".........", ".........", ".........", ".........", "........."};
        }
    }

    public static BlockState pixel(char c) {
        Block b;
        switch (c) {
            case '.': b = Blocks.BLACK_CONCRETE; break;
            case 'w': b = Blocks.WHITE_CONCRETE; break;
            case 'l': b = Blocks.LIGHT_GRAY_CONCRETE; break;
            case 'g': b = Blocks.GRAY_CONCRETE; break;
            case 'r': b = Blocks.RED_CONCRETE; break;
            case 'o': b = Blocks.ORANGE_CONCRETE; break;
            case 'y': b = Blocks.YELLOW_CONCRETE; break;
            case 'u': b = Blocks.LIME_CONCRETE; break;
            case 'n': b = Blocks.GREEN_CONCRETE; break;
            case 'c': b = Blocks.CYAN_CONCRETE; break;
            case 'a': b = Blocks.LIGHT_BLUE_CONCRETE; break;
            case 'b': b = Blocks.BLUE_CONCRETE; break;
            case 'p': b = Blocks.PURPLE_CONCRETE; break;
            case 'm': b = Blocks.MAGENTA_CONCRETE; break;
            case 'k': b = Blocks.PINK_CONCRETE; break;
            case 't': b = Blocks.BROWN_CONCRETE; break;
            case 'I': b = Blocks.IRON_BLOCK; break;
            case 'D': b = Blocks.GOLD_BLOCK; break;
            default: b = Blocks.BLACK_CONCRETE; break;
        }
        return b.defaultBlockState();
    }

    /** Color ARGB de cada pixel (para dibujar el arte en el libro). */
    public static int rgb(char c) {
        switch (c) {
            case '.': return 0xFF0C0C0E;
            case 'w': return 0xFFEBEBEB;
            case 'l': return 0xFFA0A0A0;
            case 'g': return 0xFF46464B;
            case 'r': return 0xFFB42828;
            case 'o': return 0xFFE67814;
            case 'y': return 0xFFF0D228;
            case 'u': return 0xFF6EC832;
            case 'n': return 0xFF2D6E23;
            case 'c': return 0xFF1E8C96;
            case 'a': return 0xFF6EC8E6;
            case 'b': return 0xFF283CAA;
            case 'p': return 0xFF6E2896;
            case 'm': return 0xFFBE32AA;
            case 'k': return 0xFFF096AA;
            case 't': return 0xFF6E4628;
            case 'I': return 0xFFDCDCDC;
            case 'D': return 0xFFFADC46;
            default: return 0xFF0C0C0E;
        }
    }
}
