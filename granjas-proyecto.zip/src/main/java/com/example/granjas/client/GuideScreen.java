package com.example.granjas.client;

import com.example.granjas.FarmArt;
import com.example.granjas.FarmKind;
import com.example.granjas.FarmSchematic;
import com.example.granjas.ModRegistry;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.item.ItemStack;

/** Libro de guia: como funciona, importante, indice, y una pagina por cada granja y construccion. */
public class GuideScreen extends Screen {
    private static final int W = 270;
    private static final int H = 214;
    private static final int INTRO_PAGES = 3;
    private static final FarmKind[] KINDS = FarmKind.values();

    private int page = 0;
    private int left;
    private int top;
    private Button prev;
    private Button next;
    private Button catFarms;
    private Button catBuilds;

    public GuideScreen() {
        super(Component.translatable("gui.granjas.guide_title"));
    }

    private int lastPage() {
        return INTRO_PAGES + KINDS.length - 1;
    }

    private static int count(boolean build) {
        int n = 0;
        for (FarmKind k : KINDS) {
            if (k.isBuild() == build) n++;
        }
        return n;
    }

    private static int firstPage(boolean build) {
        for (int i = 0; i < KINDS.length; i++) {
            if (KINDS[i].isBuild() == build) return INTRO_PAGES + i;
        }
        return INTRO_PAGES;
    }

    @Override
    protected void init() {
        left = (width - W) / 2;
        top = (height - H) / 2;
        int by = top + H - 26;
        prev = addRenderableWidget(Button.builder(Component.literal("<"), b -> go(page - 1))
                .bounds(left + 10, by, 40, 20).build());
        next = addRenderableWidget(Button.builder(Component.literal(">"), b -> go(page + 1))
                .bounds(left + W - 50, by, 40, 20).build());
        index = addRenderableWidget(Button.builder(Component.translatable("guide.granjas.index_title"), b -> go(2))
                .bounds(left + W / 2 - 40, by, 80, 20).build());
        catFarms = addRenderableWidget(Button.builder(
                        Component.translatable("gui.granjas.cat_farms").append(" (" + count(false) + ")"), b -> go(firstPage(false)))
                .bounds(left + 40, top + 52, W - 80, 24).build());
        catBuilds = addRenderableWidget(Button.builder(
                        Component.translatable("gui.granjas.cat_builds").append(" (" + count(true) + ")"), b -> go(firstPage(true)))
                .bounds(left + 40, top + 86, W - 80, 24).build());
        updateButtons();
    }

    private Button index;

    private void go(int p) {
        page = Math.max(0, Math.min(lastPage(), p));
        updateButtons();
    }

    private void updateButtons() {
        prev.active = page > 0;
        next.active = page < lastPage();
        boolean onIndex = page == 2;
        catFarms.visible = onIndex;
        catFarms.active = onIndex;
        catBuilds.visible = onIndex;
        catBuilds.active = onIndex;
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.renderBackground(g, mouseX, mouseY, partialTick);
        g.fill(left - 3, top - 3, left + W + 3, top + H + 3, 0xFF2A1B0E);
        g.fill(left, top, left + W, top + H, 0xFFE2D3A2);
        g.fill(left + 4, top + 4, left + W - 4, top + H - 4, 0xFFEFE4C0);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);
        if (page == 0) {
            drawText(g, "gui.granjas.guide_title", "guide.granjas.how.", 6);
        } else if (page == 1) {
            drawText(g, "guide.granjas.notes_title", "guide.granjas.note.", 4);
        } else if (page == 2) {
            g.drawString(font, Component.translatable("guide.granjas.index_title"), left + 14, top + 14, 0xFF5A3A12, false);
            g.drawString(font, Component.translatable("gui.granjas.guide_hint"), left + 14, top + 32, 0xFF2B2B2B, false);
        } else {
            drawFarm(g, KINDS[page - INTRO_PAGES]);
        }
        String foot = (page + 1) + "/" + (lastPage() + 1);
        g.drawString(font, foot, left + 56, top + H - 20, 0xFF5A3A12, false);
    }

    private void drawText(GuiGraphics g, String titleKey, String prefix, int count) {
        int y = top + 12;
        g.drawString(font, Component.translatable(titleKey), left + 14, y, 0xFF5A3A12, false);
        y += 16;
        for (int i = 1; i <= count; i++) {
            for (FormattedCharSequence line : font.split(Component.translatable(prefix + i), W - 28)) {
                g.drawString(font, line, left + 14, y, 0xFF2B2B2B, false);
                y += 10;
            }
            y += 4;
        }
    }

    private void drawFarm(GuiGraphics g, FarmKind k) {
        int tx = left + 14;
        ItemStack icon = new ItemStack(ModRegistry.FARM_ITEMS.get(k).get());
        g.renderItem(icon, tx, top + 10);
        String name = font.plainSubstrByWidth(k.displayName().getString(), 170);
        g.drawString(font, name, tx + 22, top + 14, 0xFF7A4A00, false);

        // Pixel art de la granja (el mismo que se construye enfrente)
        if (k.artKey != null) {
            String[] art = FarmArt.get(k.artKey);
            int px = left + W - 14 - 36;
            int py = top + 10;
            g.fill(px - 2, py - 2, px + 38, py + 38, 0xFF2A1B0E);
            for (int r = 0; r < 9; r++) {
                for (int c = 0; c < 9; c++) {
                    g.fill(px + c * 4, py + r * 4, px + c * 4 + 4, py + r * 4 + 4, FarmArt.rgb(art[r].charAt(c)));
                }
            }
        }

        FarmSchematic s = k.schematic();
        if (s != null) {
            g.drawString(font, Component.translatable(k.dimsKey(), s.sx, s.sy, s.sz), tx, top + 32, 0xFF305080, false);
        }
        g.drawString(font, Component.translatable(k.realKey()), tx, top + 44, 0xFF1B8A2E, false);

        String noteKey = k.entityNoteKey();
        if (noteKey != null) {
            int ny = top + 62;
            for (FormattedCharSequence line : font.split(Component.translatable("guide.granjas.note." + noteKey), W - 28)) {
                g.drawString(font, line, tx, ny, 0xFF9A3B00, false);
                ny += 10;
            }
        }

        List<FarmKind.Cost> costs = k.cost();
        g.drawString(font, Component.translatable("guide.granjas.materials", costs.size()), tx, top + 96, 0xFF5A3A12, false);
        int shown = Math.min(8, costs.size());
        for (int i = 0; i < shown; i++) {
            FarmKind.Cost c = costs.get(i);
            int ex = tx + (i % 2) * 124;
            int ey = top + 108 + (i / 2) * 18;
            ItemStack stack = c.icon();
            g.renderItem(stack, ex, ey);
            String label = c.count() + "x " + stack.getHoverName().getString();
            g.drawString(font, font.plainSubstrByWidth(label, 100), ex + 20, ey + 4, 0xFF2B2B2B, false);
        }
    }
}
