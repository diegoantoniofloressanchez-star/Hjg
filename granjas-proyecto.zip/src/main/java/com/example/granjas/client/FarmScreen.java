package com.example.granjas.client;

import com.example.granjas.FarmBlockEntity;
import com.example.granjas.FarmKind;
import com.example.granjas.FarmMenu;
import com.example.granjas.FarmSchematic;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

/** Interfaz principal: izquierda = huecos, derecha = lista de materiales (entregado / necesario) con scroll. */
public class FarmScreen extends AbstractContainerScreen<FarmMenu> {
    private static final int LEFT_W = 176;
    private static final int GAP = 4;
    private static final int PANEL_W = 140;
    private static final int VISIBLE = 6;

    private Button buildButton;
    private Button flipButton;
    private Button scrollUp;
    private Button scrollDown;
    private boolean wasComplete;
    private int scroll = 0;

    public FarmScreen(FarmMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageWidth = LEFT_W + GAP + PANEL_W;
        this.imageHeight = 190;
        this.inventoryLabelY = 96;
    }

    @Override
    protected void init() {
        super.init();
        int px = leftPos + LEFT_W + GAP;
        buildButton = addRenderableWidget(Button.builder(Component.translatable("gui.granjas.build"), b -> send(0))
                .bounds(px + 6, topPos + 166, 70, 18).build());
        flipButton = addRenderableWidget(Button.builder(Component.translatable("gui.granjas.flip"), b -> send(2))
                .bounds(px + 80, topPos + 166, PANEL_W - 86, 18).build());
        scrollUp = addRenderableWidget(Button.builder(Component.literal("^"), b -> scrollBy(-3))
                .bounds(px + PANEL_W - 24, topPos + 40, 18, 16).build());
        scrollDown = addRenderableWidget(Button.builder(Component.literal("v"), b -> scrollBy(3))
                .bounds(px + PANEL_W - 24, topPos + 40 + (VISIBLE - 1) * 18, 18, 16).build());
        wasComplete = isComplete();
        buildButton.active = wasComplete;
        updateScroll();
    }

    private int maxScroll() {
        return Math.max(0, menu.kind.cost().size() - VISIBLE);
    }

    private void scrollBy(int delta) {
        scroll = Math.max(0, Math.min(maxScroll(), scroll + delta));
        updateScroll();
    }

    private void updateScroll() {
        scrollUp.visible = maxScroll() > 0;
        scrollDown.visible = maxScroll() > 0;
        scrollUp.active = scroll > 0;
        scrollDown.active = scroll < maxScroll();
    }

    @Override
    protected void containerTick() {
        super.containerTick();
        boolean complete = isComplete();
        if (buildButton != null) buildButton.active = complete;
        if (flipButton != null) {
            flipButton.setMessage(Component.translatable(menu.flipped() ? "gui.granjas.flip_on" : "gui.granjas.flip"));
        }
        // Al completar los materiales, se abre sola la pantalla de aceptar/rechazar
        if (complete && !wasComplete) send(0);
        wasComplete = complete;
    }

    private void send(int id) {
        if (minecraft != null && minecraft.gameMode != null) {
            minecraft.gameMode.handleInventoryButtonClick(menu.containerId, id);
        }
    }

    /** Entregado = banco + lo que hay en los huecos. */
    private int haveAt(int index, FarmKind.Cost c) {
        int n = menu.bankOf(index);
        for (int i = 0; i < FarmBlockEntity.SIZE; i++) {
            ItemStack s = menu.slots.get(i).getItem();
            if (s.is(c.item())) n += s.getCount();
        }
        return n;
    }

    private boolean isComplete() {
        List<FarmKind.Cost> costs = menu.kind.cost();
        if (costs.isEmpty()) return false;
        if (minecraft != null && minecraft.player != null && minecraft.player.isCreative()) return true;
        for (int i = 0; i < costs.size(); i++) {
            if (haveAt(i, costs.get(i)) < costs.get(i).count()) return false;
        }
        return true;
    }

    @Override
    protected void renderBg(GuiGraphics g, float partialTick, int mouseX, int mouseY) {
        int x = leftPos;
        int y = topPos;
        panel(g, x, y, LEFT_W, imageHeight);
        panel(g, x + LEFT_W + GAP, y, PANEL_W, imageHeight);
        for (Slot s : menu.slots) {
            int sx = x + s.x;
            int sy = y + s.y;
            g.fill(sx - 1, sy - 1, sx + 17, sy + 17, 0xFF373737);
            g.fill(sx, sy, sx + 16, sy + 16, 0xFF8B8B8B);
        }
        drawRequirements(g, x + LEFT_W + GAP, y);
    }

    private void drawRequirements(GuiGraphics g, int px, int py) {
        g.drawString(font, Component.translatable("gui.granjas.requirements"), px + 8, py + 6, 0xFF404040, false);
        FarmSchematic s = menu.kind.schematic();
        if (s != null) {
            g.drawString(font, Component.translatable("gui.granjas.schem_size", s.sx, s.sy, s.sz), px + 8, py + 17, 0xFF305080, false);
            g.drawString(font, Component.translatable(menu.kind.realKey()), px + 8, py + 28, 0xFF1B8A2E, false);
        }
        List<FarmKind.Cost> costs = menu.kind.cost();
        for (int row = 0; row < VISIBLE; row++) {
            int i = scroll + row;
            if (i >= costs.size()) break;
            FarmKind.Cost c = costs.get(i);
            int ey = py + 40 + row * 18;
            int have = haveAt(i, c);
            boolean ok = have >= c.count();
            ItemStack icon = c.icon();
            g.renderItem(icon, px + 8, ey);
            String name = font.plainSubstrByWidth(icon.getHoverName().getString(), PANEL_W - 62);
            g.drawString(font, name, px + 28, ey, 0xFF404040, false);
            g.drawString(font, Math.min(have, c.count()) + " / " + c.count(), px + 28, ey + 9, ok ? 0xFF1B8A2E : 0xFFB02020, false);
        }
        int from = costs.isEmpty() ? 0 : scroll + 1;
        int to = Math.min(costs.size(), scroll + VISIBLE);
        g.drawString(font, from + "-" + to + " / " + costs.size(), px + 8, py + 150, 0xFF404040, false);
    }

    static void panel(GuiGraphics g, int x, int y, int w, int h) {
        g.fill(x, y, x + w, y + h, 0xFF000000);
        g.fill(x + 1, y + 1, x + w - 1, y + h - 1, 0xFFC6C6C6);
        g.fill(x + 1, y + 1, x + w - 2, y + 2, 0xFFFFFFFF);
        g.fill(x + 1, y + 1, x + 2, y + h - 2, 0xFFFFFFFF);
        g.fill(x + 2, y + h - 2, x + w - 1, y + h - 1, 0xFF555555);
        g.fill(x + w - 2, y + 2, x + w - 1, y + h - 1, 0xFF555555);
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mouseX, int mouseY) {
        super.renderLabels(g, mouseX, mouseY);
        g.drawString(font, Component.translatable("gui.granjas.materials"), 8, 18, 0xFF404040, false);
        int y = 70;
        for (FormattedCharSequence line : font.split(Component.translatable("gui.granjas.hint"), LEFT_W - 16)) {
            g.drawString(font, line, 8, y, 0xFF555555, false);
            y += 10;
        }
    }
}
