package com.example.granjas.client;

import com.example.granjas.FarmConfirmMenu;
import com.example.granjas.FarmKind;
import com.example.granjas.FarmSchematic;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

/** Segunda interfaz: resumen + botones ACEPTAR / RECHAZAR. */
public class FarmConfirmScreen extends AbstractContainerScreen<FarmConfirmMenu> {
    private static final int W = 200;
    private static final int H = 190;

    public FarmConfirmScreen(FarmConfirmMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageWidth = W;
        this.imageHeight = H;
    }

    @Override
    protected void init() {
        super.init();
        addRenderableWidget(Button.builder(Component.translatable("gui.granjas.accept"), b -> send(0))
                .bounds(leftPos + 8, topPos + 168, 90, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.granjas.reject"), b -> send(1))
                .bounds(leftPos + W - 98, topPos + 168, 90, 20).build());
    }

    private void send(int id) {
        if (minecraft != null && minecraft.gameMode != null) {
            minecraft.gameMode.handleInventoryButtonClick(menu.containerId, id);
        }
    }

    @Override
    protected void renderBg(GuiGraphics g, float partialTick, int mouseX, int mouseY) {
        int x = leftPos;
        int y = topPos;
        FarmScreen.panel(g, x, y, W, H);

        FarmSchematic s = menu.kind.schematic();
        g.drawString(font, Component.translatable("gui.granjas.confirm_title"), x + 8, y + 20, 0xFF305080, false);
        if (s != null) {
            g.drawString(font, Component.translatable("gui.granjas.schem_size", s.sx, s.sy, s.sz), x + 8, y + 32, 0xFF305080, false);
        }
        g.drawString(font, Component.translatable("gui.granjas.confirm_text"), x + 8, y + 44, 0xFF404040, false);

        List<FarmKind.Cost> costs = menu.kind.cost();
        int shown = Math.min(8, costs.size());
        for (int i = 0; i < shown; i++) {
            FarmKind.Cost c = costs.get(i);
            int ex = x + 8 + (i % 2) * 96;
            int ey = y + 58 + (i / 2) * 20;
            ItemStack icon = c.icon();
            g.renderItem(icon, ex, ey);
            String label = c.count() + "x " + icon.getHoverName().getString();
            g.drawString(font, font.plainSubstrByWidth(label, 76), ex + 20, ey + 4, 0xFF404040, false);
        }
        if (costs.size() > shown) {
            g.drawString(font, Component.translatable("gui.granjas.more", costs.size() - shown), x + 8, y + 138, 0xFF555555, false);
        }
        String noteKey = menu.kind.entityNoteKey();
        if (noteKey != null) {
            int ny = y + 150;
            for (FormattedCharSequence line : font.split(Component.translatable("guide.granjas.note." + noteKey), W - 16)) {
                g.drawString(font, line, x + 8, ny, 0xFF9A3B00, false);
                ny += 10;
            }
        }
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mouseX, int mouseY) {
        g.drawString(font, title, titleLabelX, titleLabelY, 0xFF404040, false);
    }
}
