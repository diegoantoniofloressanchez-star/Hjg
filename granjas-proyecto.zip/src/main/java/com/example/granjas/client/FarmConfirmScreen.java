package com.example.granjas.client;

import com.example.granjas.FarmConfirmMenu;
import com.example.granjas.FarmKind;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

/** Segunda interfaz: resumen + botones ACEPTAR / RECHAZAR. */
public class FarmConfirmScreen extends AbstractContainerScreen<FarmConfirmMenu> {
    private static final int W = 200;
    private static final int H = 168;

    public FarmConfirmScreen(FarmConfirmMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageWidth = W;
        this.imageHeight = H;
    }

    @Override
    protected void init() {
        super.init();
        addRenderableWidget(Button.builder(Component.translatable("gui.granjas.accept"), b -> send(0))
                .bounds(leftPos + 8, topPos + 142, 90, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.granjas.reject"), b -> send(1))
                .bounds(leftPos + W - 98, topPos + 142, 90, 20).build());
    }

    private void send(int id) {
        if (minecraft != null && minecraft.gameMode != null) {
            minecraft.gameMode.handleInventoryButtonClick(menu.containerId, id);
        }
    }

    @Override
    protected void renderBg(GuiGraphics g, float partialTick, int mouseX, int mouseY) {
        int x = leftPos;
        int y = topPos;
        FarmScreen.panel(g, x, y, W, H);

        g.drawString(font, Component.translatable("gui.granjas.confirm_title", menu.tier), x + 8, y + 20, 0xFF305080, false);
        g.drawString(font, Component.translatable("gui.granjas.confirm_text"), x + 8, y + 32, 0xFF404040, false);

        List<FarmKind.Cost> costs = menu.kind.cost(menu.tier);
        for (int i = 0; i < costs.size(); i++) {
            FarmKind.Cost c = costs.get(i);
            int col = i % 2;
            int row = i / 2;
            int ex = x + 8 + col * 96;
            int ey = y + 46 + row * 20;
            ItemStack icon = c.icon();
            g.renderItem(icon, ex, ey);
            String label = c.count() + "x " + icon.getHoverName().getString();
            g.drawString(font, font.plainSubstrByWidth(label, 76), ex + 20, ey + 4, 0xFF404040, false);
        }

        String secs = String.format(Locale.ROOT, "%.1f", menu.kind.interval(menu.tier) / 20.0);
        g.drawString(font, Component.translatable("gui.granjas.production", secs, menu.kind.multiplier(menu.tier)),
                x + 8, y + 118, 0xFF404040, false);
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mouseX, int mouseY) {
        g.drawString(font, title, titleLabelX, titleLabelY, 0xFF404040, false);
    }
}
