package com.example.granjas;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BambooLeaves;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;

/** Construye las estructuras (9x9 alrededor del bloque controlador, que nunca se toca). */
public final class FarmBuilder {
    public static final int R = 4;      // radio: 4 -> 9x9
    private static final int TOP = 4;   // altura del techo (en bloques sobre el controlador)
    private static final int F = Block.UPDATE_ALL;

    private FarmBuilder() {}

    public static boolean fitsHeight(Level level, BlockPos o) {
        return !level.isOutsideBuildHeight(o.getY() - 1) && !level.isOutsideBuildHeight(o.getY() + TOP);
    }

    /** No construye sobre cofres/hornos/otros controladores ni sobre bedrock. */
    public static boolean isAreaSafe(Level level, BlockPos o) {
        for (BlockPos p : BlockPos.betweenClosed(o.offset(-R, -1, -R), o.offset(R, TOP, R))) {
            if (p.equals(o)) continue;
            if (level.getBlockEntity(p) != null) return false;
            if (level.getBlockState(p).getDestroySpeed(level, p) < 0) return false;
        }
        return true;
    }

    /** Contorno de particulas del area (para ver donde se va a construir). */
    public static void showOutline(ServerLevel level, BlockPos o) {
        double y = o.getY() + 0.15;
        for (int i = -R; i <= R; i++) {
            point(level, o.getX() + i + 0.5, y, o.getZ() - R + 0.5);
            point(level, o.getX() + i + 0.5, y, o.getZ() + R + 0.5);
            point(level, o.getX() - R + 0.5, y, o.getZ() + i + 0.5);
            point(level, o.getX() + R + 0.5, y, o.getZ() + i + 0.5);
        }
        for (int sx = -R; sx <= R; sx += 2 * R) {
            for (int sz = -R; sz <= R; sz += 2 * R) {
                for (int h = 1; h <= TOP; h++) {
                    point(level, o.getX() + sx + 0.5, o.getY() + h + 0.5, o.getZ() + sz + 0.5);
                }
            }
        }
    }

    private static void point(ServerLevel level, double x, double y, double z) {
        level.sendParticles(ParticleTypes.END_ROD, x, y, z, 1, 0.0, 0.0, 0.0, 0.0);
    }

    // ------------------------------------------------------------------ BUILD

    public static void build(ServerLevel level, BlockPos o, FarmKind kind, int tier) {
        BlockState air = Blocks.AIR.defaultBlockState();
        // 1) Despejar (menos el controlador)
        for (BlockPos p : BlockPos.betweenClosed(o.offset(-R, 0, -R), o.offset(R, TOP, R))) {
            if (!p.equals(o)) level.setBlock(p, air, Block.UPDATE_CLIENTS);
        }
        // 2) Estructura segun tipo
        switch (kind.theme) {
            case SUGAR_CANE -> sugarCane(level, o);
            case BAMBOO -> bamboo(level, o);
            case CACTUS -> cactus(level, o);
            case PUMPKIN -> pumpkinOrMelon(level, o, false);
            case MELON -> pumpkinOrMelon(level, o, true);
            default -> mobRoom(level, o, kind, tier);
        }
        // 3) Pilares de las esquinas: cambian con el nivel
        corners(level, o, tier, kind.theme.isMob());
    }

    private static void sugarCane(ServerLevel l, BlockPos o) {
        for (int dx = -R; dx <= R; dx++) {
            for (int dz = -R; dz <= R; dz++) {
                boolean water = dz == -3 || dz == 0 || dz == 3;
                l.setBlock(o.offset(dx, -1, dz), water ? Blocks.WATER.defaultBlockState() : Blocks.SAND.defaultBlockState(), F);
            }
        }
        for (int dx = -R; dx <= R; dx++) {
            for (int dz = -R; dz <= R; dz++) {
                if (dz == -3 || dz == 0 || dz == 3) continue;
                for (int h = 0; h < 3; h++) {
                    l.setBlock(o.offset(dx, h, dz), Blocks.SUGAR_CANE.defaultBlockState(), F);
                }
            }
        }
    }

    private static void bamboo(ServerLevel l, BlockPos o) {
        for (int dx = -R; dx <= R; dx++) {
            for (int dz = -R; dz <= R; dz++) {
                l.setBlock(o.offset(dx, -1, dz), Blocks.PODZOL.defaultBlockState(), F);
            }
        }
        for (int dx = -R; dx <= R; dx++) {
            for (int dz = -R; dz <= R; dz++) {
                if (((dx + dz) & 1) != 0 || (dx == 0 && dz == 0)) continue;
                for (int h = 0; h < 4; h++) {
                    BlockState s = Blocks.BAMBOO.defaultBlockState();
                    if (h == 3) s = s.setValue(BlockStateProperties.BAMBOO_LEAVES, BambooLeaves.LARGE);
                    else if (h == 2) s = s.setValue(BlockStateProperties.BAMBOO_LEAVES, BambooLeaves.SMALL);
                    l.setBlock(o.offset(dx, h, dz), s, F);
                }
            }
        }
    }

    private static void cactus(ServerLevel l, BlockPos o) {
        for (int dx = -R; dx <= R; dx++) {
            for (int dz = -R; dz <= R; dz++) {
                l.setBlock(o.offset(dx, -1, dz), Blocks.SAND.defaultBlockState(), F);
            }
        }
        for (int dx = -R; dx <= R; dx++) {
            for (int dz = -R; dz <= R; dz++) {
                if (((dx + dz) & 1) != 0 || (dx == 0 && dz == 0)) continue;
                for (int h = 0; h < 3; h++) {
                    l.setBlock(o.offset(dx, h, dz), Blocks.CACTUS.defaultBlockState(), F);
                }
            }
        }
    }

    private static void pumpkinOrMelon(ServerLevel l, BlockPos o, boolean melon) {
        BlockState farmland = Blocks.FARMLAND.defaultBlockState().setValue(BlockStateProperties.MOISTURE, 7);
        Block stem = melon ? Blocks.MELON_STEM : Blocks.PUMPKIN_STEM;
        Block fruit = melon ? Blocks.MELON : Blocks.PUMPKIN;
        for (int dx = -R; dx <= R; dx++) {
            for (int dz = -R; dz <= R; dz++) {
                boolean evenRow = (dz & 1) == 0;
                BlockState floor;
                if (dx == 0 && dz == 0) floor = Blocks.WATER.defaultBlockState();   // agua bajo el controlador
                else if (!evenRow) floor = Blocks.DIRT_PATH.defaultBlockState();    // pasillos
                else if ((dx & 1) != 0) floor = farmland;                           // aqui van los tallos
                else floor = Blocks.DIRT.defaultBlockState();                       // aqui van los frutos
                l.setBlock(o.offset(dx, -1, dz), floor, F);
            }
        }
        for (int dx = -R; dx <= R; dx++) {
            for (int dz = -R; dz <= R; dz++) {
                if ((dz & 1) != 0 || (dx == 0 && dz == 0)) continue;
                if ((dx & 1) != 0) {
                    l.setBlock(o.offset(dx, 0, dz), stem.defaultBlockState().setValue(BlockStateProperties.AGE_7, 7), F);
                } else {
                    l.setBlock(o.offset(dx, 0, dz), fruit.defaultBlockState(), F);
                }
            }
        }
    }

    private static void mobRoom(ServerLevel l, BlockPos o, FarmKind kind, int tier) {
        BlockState wall = switch (tier) {
            case 1 -> Blocks.STONE_BRICKS.defaultBlockState();
            case 2 -> Blocks.DEEPSLATE_BRICKS.defaultBlockState();
            default -> Blocks.POLISHED_BLACKSTONE_BRICKS.defaultBlockState();
        };
        BlockState air = Blocks.AIR.defaultBlockState();
        for (int dx = -R; dx <= R; dx++) {
            for (int dz = -R; dz <= R; dz++) {
                l.setBlock(o.offset(dx, -1, dz), wall, F);   // suelo
                l.setBlock(o.offset(dx, TOP, dz), wall, F);  // techo
                if (Math.abs(dx) == R || Math.abs(dz) == R) {
                    for (int h = 0; h < TOP; h++) l.setBlock(o.offset(dx, h, dz), wall, F);
                }
            }
        }
        // Puerta
        l.setBlock(o.offset(0, 0, R), air, F);
        l.setBlock(o.offset(0, 1, R), air, F);

        if (kind.spawner) {
            // Jaula de barrotes con la "cabeza" del mob en el centro
            BlockState decor = switch (kind.theme) {
                case ZOMBIE -> Blocks.ZOMBIE_HEAD.defaultBlockState();
                case SKELETON -> Blocks.SKELETON_SKULL.defaultBlockState();
                case CREEPER -> Blocks.CREEPER_HEAD.defaultBlockState();
                default -> Blocks.COBWEB.defaultBlockState();
            };
            for (int dx = -1; dx <= 1; dx++) {
                for (int dz = -3; dz <= -1; dz++) {
                    boolean center = dx == 0 && dz == -2;
                    if (center) {
                        l.setBlock(o.offset(dx, 0, dz), decor, F);
                    } else {
                        l.setBlock(o.offset(dx, 0, dz), Blocks.IRON_BARS.defaultBlockState(), F);
                        l.setBlock(o.offset(dx, 1, dz), Blocks.IRON_BARS.defaultBlockState(), F);
                    }
                    l.setBlock(o.offset(dx, 2, dz), Blocks.IRON_BARS.defaultBlockState(), F);
                }
            }
        }
    }

    private static void corners(ServerLevel l, BlockPos o, int tier, boolean mobs) {
        BlockState pillar = switch (tier) {
            case 1 -> Blocks.CHISELED_STONE_BRICKS.defaultBlockState();
            case 2 -> Blocks.IRON_BLOCK.defaultBlockState();
            default -> Blocks.DIAMOND_BLOCK.defaultBlockState();
        };
        int height = mobs ? TOP : 2;
        for (int sx = -R; sx <= R; sx += 2 * R) {
            for (int sz = -R; sz <= R; sz += 2 * R) {
                for (int h = 0; h < height; h++) l.setBlock(o.offset(sx, h, sz), pillar, F);
                if (!mobs) l.setBlock(o.offset(sx, height, sz), Blocks.TORCH.defaultBlockState(), F);
            }
        }
    }
}
