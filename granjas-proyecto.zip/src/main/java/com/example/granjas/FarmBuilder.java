package com.example.granjas;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Construye un schematic real. El bloque controlador queda en el MEDIO del borde cercano,
 * pegado a la granja, y la granja se extiende hacia donde miraba el jugador al colocarlo.
 * Se construye capa por capa hacia arriba, fila por fila.
 */
public final class FarmBuilder {
    /** Letrero de pixel art: marco de 11x11 con arte de 9x9 dentro. */
    private static final int BB_W = 11;
    private static final int BB_H = 11;
    private static final int BB = BB_W * BB_H;
    /** Borde limite: margen alrededor de la granja. */
    public static final int LIMIT_MARGIN = 2;
    /** Sin actualizar vecinos ni formas: los bloques quedan tal cual vienen en el schematic. */
    private static final int FLAGS = Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE;

    private FarmBuilder() {}

    // ----------------------------------------------------------- giro

    public static Direction facingOf(Level level, BlockPos o) {
        BlockState st = level.getBlockState(o);
        return st.hasProperty(FarmBlock.FACING) ? st.getValue(FarmBlock.FACING) : Direction.SOUTH;
    }

    /** El schematic original "mira" al sur: SUR = sin giro. */
    public static Rotation rotationFor(Direction facing) {
        switch (facing) {
            case WEST:
                return Rotation.CLOCKWISE_90;
            case NORTH:
                return Rotation.CLOCKWISE_180;
            case EAST:
                return Rotation.COUNTERCLOCKWISE_90;
            default:
                return Rotation.NONE;
        }
    }

    /** u = este (+), v = sur (+) en el marco del schematic. */
    private static int rotX(Rotation r, int u, int v) {
        switch (r) {
            case CLOCKWISE_90:
                return -v;
            case CLOCKWISE_180:
                return -u;
            case COUNTERCLOCKWISE_90:
                return v;
            default:
                return u;
        }
    }

    private static int rotZ(Rotation r, int u, int v) {
        switch (r) {
            case CLOCKWISE_90:
                return u;
            case CLOCKWISE_180:
                return -v;
            case COUNTERCLOCKWISE_90:
                return -u;
            default:
                return v;
        }
    }

    private static int u0(FarmSchematic s) {
        return -(s.sx / 2);
    }

    // ----------------------------------------------------------- datos

    public static int totalCells(FarmKind kind) {
        FarmSchematic s = kind.schematic();
        return s == null ? 0 : s.cellCount() + (kind.isBuild() ? 0 : BB);
    }

    /** Celdas por tick: una fila como minimo; las enormes tardan unos 3 minutos. */
    public static int cellsPerTick(FarmKind kind) {
        FarmSchematic s = kind.schematic();
        if (s == null) return 1;
        return Math.max(s.sx, (s.cellCount() + (kind.isBuild() ? 0 : BB)) / 3600 + 1);
    }

    public static boolean fitsHeight(Level level, BlockPos o, FarmKind kind) {
        FarmSchematic s = kind.schematic();
        if (s == null) return false;
        int top = o.getY() + (kind.isBuild() ? s.sy : Math.max(s.sy, BB_H)) - 1;
        return !level.isOutsideBuildHeight(o.getY()) && !level.isOutsideBuildHeight(top);
    }

    /** No construye sobre cofres/hornos/otros controladores ni sobre bedrock. */
    public static boolean isAreaSafe(Level level, BlockPos o, FarmKind kind) {
        FarmSchematic s = kind.schematic();
        if (s == null) return false;
        Rotation rot = rotationFor(facingOf(level, o));
        int u0 = u0(s);
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (int y = 0; y < s.sy; y++) {
            for (int z = 0; z < s.sz; z++) {
                for (int x = 0; x < s.sx; x++) {
                    int u = u0 + x;
                    int v = z + 1;
                    p.set(o.getX() + rotX(rot, u, v), o.getY() + y, o.getZ() + rotZ(rot, u, v));
                    BlockState st = level.getBlockState(p);
                    if (st.hasBlockEntity() || st.getDestroySpeed(level, p) < 0) return false;
                }
            }
        }
        for (int gy = 0; gy < BB_H && !kind.isBuild(); gy++) {
            for (int gx = 0; gx < BB_W; gx++) {
                int u = -3 - gx;
                p.set(o.getX() + rotX(rot, u, 0), o.getY() + gy, o.getZ() + rotZ(rot, u, 0));
                BlockState st = level.getBlockState(p);
                if (st.hasBlockEntity() || st.getDestroySpeed(level, p) < 0) return false;
            }
        }
        return true;
    }

    // ----------------------------------------------------------- contornos

    /** Azul = terreno que ocupara (hasta que se construya). Blanco = borde limite (siempre). */
    public static void showOutlines(ServerLevel level, BlockPos o, FarmKind kind, boolean built) {
        FarmSchematic s = kind.schematic();
        if (s == null) return;
        Rotation rot = rotationFor(facingOf(level, o));
        int u0 = u0(s);
        int u1 = u0 + s.sx - 1;
        int v0 = 1;
        int v1 = s.sz;
        ring(level, o, rot, u0 - LIMIT_MARGIN, u1 + LIMIT_MARGIN, v0 - LIMIT_MARGIN, v1 + LIMIT_MARGIN, ParticleTypes.END_ROD, 0.9);
        if (!built) {
            ring(level, o, rot, u0, u1, v0, v1, ParticleTypes.SOUL_FIRE_FLAME, 0.3);
        }
    }

    private static void ring(ServerLevel level, BlockPos o, Rotation rot, int u0, int u1, int v0, int v1,
                             ParticleOptions particle, double yOff) {
        for (int u = u0; u <= u1; u++) {
            point(level, o, rot, u, v0, particle, yOff);
            point(level, o, rot, u, v1, particle, yOff);
        }
        for (int v = v0 + 1; v < v1; v++) {
            point(level, o, rot, u0, v, particle, yOff);
            point(level, o, rot, u1, v, particle, yOff);
        }
    }

    private static void point(ServerLevel level, BlockPos o, Rotation rot, int u, int v, ParticleOptions particle, double yOff) {
        level.sendParticles(particle, o.getX() + rotX(rot, u, v) + 0.5, o.getY() + yOff, o.getZ() + rotZ(rot, u, v) + 0.5,
                1, 0.0, 0.0, 0.0, 0.0);
    }

    // ----------------------------------------------------------- construccion

    /** Coloca hasta 'max' celdas desde 'cursor' (capa por capa hacia arriba). Devuelve el nuevo cursor. */
    public static int buildStep(ServerLevel level, BlockPos o, FarmKind kind, int cursor, int max, boolean flip) {
        FarmSchematic s = kind.schematic();
        if (s == null) return cursor;
        Rotation rot = rotationFor(facingOf(level, o));
        BlockState[] states = s.states(flip ? rot.getRotated(Rotation.CLOCKWISE_180) : rot);
        int cells = s.cellCount();
        int total = cells + (kind.isBuild() ? 0 : BB);
        int end = Math.min(total, cursor + max);
        int u0 = u0(s);
        int plane = s.sx * s.sz;
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (int i = cursor; i < end; i++) {
            if (i < cells) {
                int y = i / plane;
                int rem = i % plane;
                int x = rem % s.sx;
                int z = rem / s.sx;
                if (flip) {
                    x = s.sx - 1 - x;
                    z = s.sz - 1 - z;
                }
                int u = u0 + x;
                int v = z + 1;
                p.set(o.getX() + rotX(rot, u, v), o.getY() + y, o.getZ() + rotZ(rot, u, v));
                level.setBlock(p, states[s.cell(i)], FLAGS);
            } else {
                int j = i - cells;
                int gx = j % BB_W;
                int gy = j / BB_W;
                int u = -3 - gx; // a la derecha del controlador, leyendose de izquierda a derecha
                p.set(o.getX() + rotX(rot, u, 0), o.getY() + gy, o.getZ() + rotZ(rot, u, 0));
                level.setBlock(p, billboardState(kind, gx, gy), FLAGS);
            }
        }
        return end;
    }

    private static BlockState billboardState(FarmKind kind, int gx, int gy) {
        boolean frameX = gx == 0 || gx == BB_W - 1;
        boolean frameY = gy == 0 || gy == BB_H - 1;
        if (frameX || frameY) {
            if (frameX && frameY) return Blocks.SEA_LANTERN.defaultBlockState();
            return Blocks.CHISELED_STONE_BRICKS.defaultBlockState();
        }
        String[] art = FarmArt.get(kind.artKey);
        int row = (BB_H - 2) - gy; // gy = 9 -> fila 0 (arriba); gy = 1 -> fila 8 (abajo)
        int col = gx - 1;
        return FarmArt.pixel(art[row].charAt(col));
    }
}
