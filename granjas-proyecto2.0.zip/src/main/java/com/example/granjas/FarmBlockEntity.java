package com.example.granjas;

import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.NonNullList;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.HopperBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Cerebro de la granja: guarda los materiales entregados (slots 0-17), la produccion (18-35),
 * el nivel, construye por filas y produce items solo cuando la granja esta construida.
 * Al ser un Container, las tolvas pueden sacar la produccion, y se suelta todo al romper el bloque.
 */
public class FarmBlockEntity extends BlockEntity implements Container, MenuProvider {
    public static final int IN = 18;
    public static final int OUT = 18;
    public static final int SIZE = IN + OUT;

    private final NonNullList<ItemStack> items = NonNullList.withSize(SIZE, ItemStack.EMPTY);
    private int tier = 0;
    private int timer = 0;
    /** Nivel que se esta construyendo ahora (0 = ninguno) y por que celda va. */
    private int buildTier = 0;
    private int buildCursor = 0;

    public FarmBlockEntity(BlockPos pos, BlockState state) {
        super(ModRegistry.FARM_BE.get(), pos, state);
    }

    public FarmKind kind() {
        return getBlockState().getBlock() instanceof FarmBlock fb ? fb.kind() : FarmKind.SUGAR_CANE_FARM;
    }

    public int tier() {
        return tier;
    }

    // ------------------------------------------------------------- Guardado

    @Override
    public void saveAdditional(ValueOutput output) {
        super.saveAdditional(output);
        output.putInt("Tier", tier);
        output.putInt("Timer", timer);
        output.putInt("BuildTier", buildTier);
        output.putInt("BuildCursor", buildCursor);
        ValueOutput.ValueOutputList list = output.childrenList("Items");
        for (int i = 0; i < SIZE; i++) {
            ItemStack s = items.get(i);
            if (!s.isEmpty()) {
                ValueOutput child = list.addChild();
                child.putInt("Slot", i);
                child.store("Item", ItemStack.CODEC, s);
            }
        }
    }

    @Override
    public void loadAdditional(ValueInput input) {
        super.loadAdditional(input);
        tier = input.getIntOr("Tier", 0);
        timer = input.getIntOr("Timer", 0);
        buildTier = input.getIntOr("BuildTier", 0);
        buildCursor = input.getIntOr("BuildCursor", 0);
        for (int i = 0; i < SIZE; i++) items.set(i, ItemStack.EMPTY);
        for (ValueInput child : input.childrenListOrEmpty("Items")) {
            int slot = child.getIntOr("Slot", -1);
            if (slot >= 0 && slot < SIZE) {
                child.read("Item", ItemStack.CODEC).ifPresent(s -> items.set(slot, s));
            }
        }
    }

    // ------------------------------------------------------------ Container

    @Override
    public int getContainerSize() {
        return SIZE;
    }

    @Override
    public boolean isEmpty() {
        for (ItemStack s : items) if (!s.isEmpty()) return false;
        return true;
    }

    @Override
    public ItemStack getItem(int slot) {
        return items.get(slot);
    }

    @Override
    public ItemStack removeItem(int slot, int amount) {
        ItemStack r = ContainerHelper.removeItem(items, slot, amount);
        if (!r.isEmpty()) setChanged();
        return r;
    }

    @Override
    public ItemStack removeItemNoUpdate(int slot) {
        return ContainerHelper.takeItem(items, slot);
    }

    @Override
    public void setItem(int slot, ItemStack stack) {
        items.set(slot, stack);
        setChanged();
    }

    @Override
    public boolean stillValid(Player player) {
        return level != null && level.getBlockEntity(worldPosition) == this
                && player.distanceToSqr(Vec3.atCenterOf(worldPosition)) <= 64.0;
    }

    @Override
    public void clearContent() {
        for (int i = 0; i < SIZE; i++) items.set(i, ItemStack.EMPTY);
    }

    @Override
    public boolean canPlaceItem(int slot, ItemStack stack) {
        return slot < IN && acceptsMaterial(stack);
    }

    @Override
    public boolean canTakeItem(Container target, int slot, ItemStack stack) {
        return slot >= IN; // las tolvas solo sacan la produccion
    }

    public boolean acceptsMaterial(ItemStack stack) {
        if (buildTier > 0 || tier >= kind().maxTier()) return false;
        for (FarmKind.Cost c : kind().cost(tier + 1)) {
            if (stack.is(c.item())) return true;
        }
        return false;
    }

    // ----------------------------------------------------------------- Menus

    @Override
    public Component getDisplayName() {
        return getBlockState().getBlock().getName();
    }

    @Override
    public AbstractContainerMenu createMenu(int id, Inventory inv, Player player) {
        return new FarmMenu(id, inv, this);
    }

    private void writeHeader(RegistryFriendlyByteBuf buf, int shownTier) {
        buf.writeBlockPos(worldPosition);
        buf.writeVarInt(kind().ordinal());
        buf.writeVarInt(shownTier);
    }

    public void openMain(ServerPlayer player) {
        if (buildTier > 0) {
            player.displayClientMessage(
                    Component.translatable("message.granjas.building", percent()).withStyle(ChatFormatting.YELLOW), true);
            return;
        }
        player.openMenu(this, buf -> writeHeader(buf, tier));
    }

    public void openConfirm(ServerPlayer player) {
        player.openMenu(
                new SimpleMenuProvider((id, inv, p) -> new FarmConfirmMenu(id, inv, this), getDisplayName()),
                buf -> writeHeader(buf, tier + 1));
    }

    // -------------------------------------------------------------- Materiales

    public int count(Item item) {
        int total = 0;
        for (int i = 0; i < IN; i++) {
            ItemStack s = items.get(i);
            if (s.is(item)) total += s.getCount();
        }
        return total;
    }

    public boolean isComplete() {
        if (buildTier > 0 || tier >= kind().maxTier()) return false;
        for (FarmKind.Cost c : kind().cost(tier + 1)) {
            if (count(c.item()) < c.count()) return false;
        }
        return true;
    }

    private void removeMaterial(Item item, int amount) {
        for (int i = 0; i < IN && amount > 0; i++) {
            ItemStack s = items.get(i);
            if (s.is(item)) {
                int n = Math.min(amount, s.getCount());
                s.shrink(n);
                amount -= n;
                if (s.isEmpty()) items.set(i, ItemStack.EMPTY);
            }
        }
    }

    /** El jugador pulso ACEPTAR en la pantalla de confirmacion: consume y empieza a construir. */
    public void acceptBuild(ServerPlayer player) {
        if (!(level instanceof ServerLevel sl) || buildTier > 0 || !isComplete()) {
            player.closeContainer();
            return;
        }
        FarmKind k = kind();
        int next = tier + 1;
        if (!FarmBuilder.fitsHeight(sl, worldPosition)) {
            player.displayClientMessage(Component.translatable("message.granjas.height").withStyle(ChatFormatting.RED), true);
            openMain(player);
            return;
        }
        if (!FarmBuilder.isAreaSafe(sl, worldPosition, k.size(next), tier == 0 ? 0 : k.size(tier))) {
            player.displayClientMessage(Component.translatable("message.granjas.blocked").withStyle(ChatFormatting.RED), true);
            openMain(player);
            return;
        }
        for (FarmKind.Cost c : k.cost(next)) removeMaterial(c.item(), c.count());
        buildTier = next;
        buildCursor = 0;
        setChanged();
        player.closeContainer();
        player.displayClientMessage(
                Component.translatable("message.granjas.started", k.displayName(), next).withStyle(ChatFormatting.GREEN), true);
    }

    // ------------------------------------------------------------------ Tick

    public static void tick(Level level, BlockPos pos, BlockState state, FarmBlockEntity be) {
        if (level.isClientSide() || !(level instanceof ServerLevel sl)) return;
        long t = level.getGameTime();
        if (be.buildTier > 0) {
            be.buildStep(sl);
        } else if (be.tier > 0) {
            be.produce(sl);
            if (t % 20 == 0) be.exportOutputs(sl);
        }
        if (t % 20 == 0 && be.buildTier == 0
                && sl.getNearestPlayer(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 48.0, false) != null) {
            FarmBuilder.showOutlines(sl, pos, be.kind(), be.tier);
        }
        if (t % 10 == 0) be.showHud(sl);
    }

    private int percent() {
        if (buildTier <= 0) return 0;
        int total = FarmBuilder.totalCells(kind().size(buildTier));
        return (int) Math.min(100L, buildCursor * 100L / total);
    }

    /** Una fila por tick, capa por capa hacia arriba. */
    private void buildStep(ServerLevel sl) {
        FarmKind k = kind();
        int size = k.size(buildTier);
        int total = FarmBuilder.totalCells(size);
        buildCursor = FarmBuilder.buildStep(sl, worldPosition, k, buildTier, buildCursor, size);
        if (buildCursor >= total) {
            tier = buildTier;
            buildTier = 0;
            buildCursor = 0;
            timer = 0;
            Vec3 center = Vec3.atCenterOf(worldPosition);
            for (ServerPlayer p : sl.players()) {
                if (p.distanceToSqr(center) < 96.0 * 96.0) {
                    p.displayClientMessage(
                            Component.translatable("message.granjas.done", k.displayName(), tier).withStyle(ChatFormatting.GREEN),
                            true);
                }
            }
        }
        setChanged();
    }

    private void produce(ServerLevel sl) {
        FarmKind k = kind();
        if (++timer < k.interval(tier)) return;
        timer = 0;
        for (ItemStack drop : k.rollDrops(tier, sl.getRandom())) {
            addToOutput(drop); // si no cabe, se pierde (produccion llena)
        }
        setChanged();
    }

    private void addToOutput(ItemStack stack) {
        ItemStack rest = stack.copy();
        for (int i = IN; i < SIZE && !rest.isEmpty(); i++) {
            ItemStack cur = items.get(i);
            if (cur.isEmpty()) {
                int n = Math.min(rest.getCount(), rest.getMaxStackSize());
                items.set(i, rest.split(n));
            } else if (ItemStack.isSameItemSameComponents(cur, rest)) {
                int room = cur.getMaxStackSize() - cur.getCount();
                if (room > 0) {
                    int n = Math.min(room, rest.getCount());
                    cur.grow(n);
                    rest.shrink(n);
                }
            }
        }
    }

    /** Empuja la produccion a cofres/tolvas pegados al controlador. */
    private void exportOutputs(ServerLevel sl) {
        boolean changed = false;
        for (Direction dir : Direction.values()) {
            Container dest = HopperBlockEntity.getContainerAt(sl, worldPosition.relative(dir));
            if (dest == null || dest == this) continue;
            for (int i = IN; i < SIZE; i++) {
                ItemStack s = items.get(i);
                if (s.isEmpty()) continue;
                int before = s.getCount();
                ItemStack rest = HopperBlockEntity.addItem(null, dest, s.copy(), dir.getOpposite());
                if (rest.getCount() != before) {
                    items.set(i, rest.isEmpty() ? ItemStack.EMPTY : rest);
                    changed = true;
                }
            }
        }
        if (changed) setChanged();
    }

    // ------------------------------------------------------- Info arriba (HUD)

    private void showHud(ServerLevel sl) {
        Vec3 center = Vec3.atCenterOf(worldPosition);
        for (ServerPlayer p : sl.players()) {
            if (p.distanceToSqr(center) > 64.0) continue;
            Vec3 eye = p.getEyePosition();
            Vec3 end = eye.add(p.getLookAngle().scale(6.0));
            BlockHitResult hit = sl.clip(new ClipContext(eye, end, ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, p));
            if (hit.getType() == HitResult.Type.BLOCK && hit.getBlockPos().equals(worldPosition)) {
                p.displayClientMessage(buildHud(), true);
            }
        }
    }

    private Component buildHud() {
        FarmKind k = kind();
        int max = k.maxTier();
        MutableComponent c = k.displayName().copy().withStyle(ChatFormatting.GOLD);
        c.append(Component.literal(" | ").withStyle(ChatFormatting.DARK_GRAY));
        if (buildTier > 0) {
            c.append(Component.translatable("hud.granjas.building", buildTier, percent()).withStyle(ChatFormatting.YELLOW));
            return c;
        }
        c.append(Component.translatable("hud.granjas.level", tier, max).withStyle(ChatFormatting.AQUA));
        c.append(Component.literal(" | ").withStyle(ChatFormatting.DARK_GRAY));
        if (tier >= max) {
            c.append(Component.translatable("hud.granjas.max").withStyle(ChatFormatting.GREEN));
        } else if (isComplete()) {
            c.append(Component.translatable("hud.granjas.ready").withStyle(ChatFormatting.GREEN));
        } else {
            List<FarmKind.Cost> cost = k.cost(tier + 1);
            for (int i = 0; i < cost.size(); i++) {
                if (i == 4) {
                    c.append(Component.literal(" ...").withStyle(ChatFormatting.GRAY));
                    break;
                }
                FarmKind.Cost need = cost.get(i);
                int have = Math.min(count(need.item()), need.count());
                boolean ok = have >= need.count();
                if (i > 0) c.append(Component.literal(", ").withStyle(ChatFormatting.GRAY));
                MutableComponent line = Component.empty();
                line.append(need.icon().getHoverName());
                line.append(Component.literal(" " + have + "/" + need.count()));
                c.append(line.withStyle(ok ? ChatFormatting.GREEN : ChatFormatting.RED));
            }
        }
        return c;
    }
}
