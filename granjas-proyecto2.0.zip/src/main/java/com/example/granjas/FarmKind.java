package com.example.granjas;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * Todas las granjas del mod. Aqui estan los TAMAÑOS, los COSTOS por nivel, la VELOCIDAD y los DROPS.
 * Ajusta los numeros a tu gusto.
 */
public enum FarmKind {
    // ---- Recursos (3 niveles) ----
    SUGAR_CANE_FARM("sugar_cane_farm", Theme.SUGAR_CANE, false),
    BAMBOO_FARM("bamboo_farm", Theme.BAMBOO, false),
    CACTUS_FARM("cactus_farm", Theme.CACTUS, false),
    PUMPKIN_FARM("pumpkin_farm", Theme.PUMPKIN, false),
    MELON_FARM("melon_farm", Theme.MELON, false),
    // ---- Mobs naturales (4 niveles; golem 5) ----
    ZOMBIE_FARM("zombie_farm", Theme.ZOMBIE, false),
    SKELETON_FARM("skeleton_farm", Theme.SKELETON, false),
    SPIDER_FARM("spider_farm", Theme.SPIDER, false),
    CREEPER_FARM("creeper_farm", Theme.CREEPER, false),
    GOLEM_FARM("golem_farm", Theme.GOLEM, false),
    // ---- Mobs con spawner (6 niveles, caras y muy rapidas) ----
    ZOMBIE_SPAWNER_FARM("zombie_spawner_farm", Theme.ZOMBIE, true),
    SKELETON_SPAWNER_FARM("skeleton_spawner_farm", Theme.SKELETON, true),
    SPIDER_SPAWNER_FARM("spider_spawner_farm", Theme.SPIDER, true),
    CREEPER_SPAWNER_FARM("creeper_spawner_farm", Theme.CREEPER, true),
    GOLEM_SPAWNER_FARM("golem_spawner_farm", Theme.GOLEM, true);

    /** Bloques extra del borde limite a cada lado, mas alla del tamaño final. */
    public static final int LIMIT_MARGIN = 2;

    public enum Theme {
        SUGAR_CANE, BAMBOO, CACTUS, PUMPKIN, MELON, ZOMBIE, SKELETON, SPIDER, CREEPER, GOLEM;

        public boolean isMob() {
            return ordinal() >= ZOMBIE.ordinal();
        }
    }

    /** Un material requerido. */
    public record Cost(Item item, int count) {
        public ItemStack icon() {
            return new ItemStack(item);
        }
    }

    /** Un drop de produccion. */
    public record Drop(Item item, int min, int max, float chance) {}

    public final String id;
    public final Theme theme;
    public final boolean spawner;

    FarmKind(String id, Theme theme, boolean spawner) {
        this.id = id;
        this.theme = theme;
        this.spawner = spawner;
    }

    public Component displayName() {
        return Component.translatable("block." + GranjasMod.MOD_ID + "." + id);
    }

    // ------------------------------------------------------------------ TAMAÑOS

    /** Lado del cuadrado de la granja en cada nivel (el numero de niveles = largo de esta lista). */
    private int[] sizes() {
        if (!theme.isMob()) return new int[] {20, 25, 40};
        if (theme == Theme.GOLEM) {
            return spawner ? new int[] {25, 32, 40, 52, 64, 72} : new int[] {25, 32, 40, 50, 60};
        }
        return spawner ? new int[] {20, 25, 32, 40, 52, 64} : new int[] {20, 25, 40, 50};
    }

    public int maxTier() {
        return sizes().length;
    }

    public int size(int tier) {
        int[] s = sizes();
        return s[Math.max(1, Math.min(tier, s.length)) - 1];
    }

    /** Lado del borde limite (siempre visible): tamaño final + margen a cada lado. */
    public int limitSize() {
        return size(maxTier()) + 2 * LIMIT_MARGIN;
    }

    // ------------------------------------------------------------------ COSTOS

    private static void add(List<Cost> out, Item item, int n) {
        for (int i = 0; i < out.size(); i++) {
            if (out.get(i).item() == item) {
                out.set(i, new Cost(item, out.get(i).count() + n));
                return;
            }
        }
        out.add(new Cost(item, n));
    }

    /** Materiales para CONSTRUIR/MEJORAR hasta el nivel indicado (1..maxTier). */
    public List<Cost> cost(int tier) {
        if (tier < 1 || tier > maxTier()) return List.of();
        List<Cost> out = new ArrayList<>();
        int i = tier - 1;

        if (!theme.isMob()) {
            add(out, baseBlock(), new int[] {128, 192, 256}[i]);
            add(out, resourceItem(), new int[] {16, 48, 128}[i]);
            switch (tier) {
                case 1 -> add(out, Items.IRON_INGOT, 8);
                case 2 -> {
                    add(out, Items.IRON_INGOT, 24);
                    add(out, Items.REDSTONE, 32);
                    add(out, Items.GLASS, 32);
                }
                default -> {
                    add(out, Items.GOLD_INGOT, 32);
                    add(out, Items.DIAMOND, 12);
                    add(out, Items.REDSTONE_BLOCK, 8);
                }
            }
            return out;
        }

        add(out, wallItem(tier), new int[] {128, 192, 256, 256, 256, 256}[i]);
        add(out, mobDrop(), (spawner ? new int[] {64, 128, 192, 256, 256, 256} : new int[] {32, 64, 128, 192, 256, 256})[i]);
        if (spawner && tier == 1) {
            add(out, Items.IRON_BARS, 16);
            Cost head = mobHeadCost();
            add(out, head.item(), head.count());
        }
        addMetal(out, tier);
        if (spawner) {
            // Spawner: caro de verdad (diamantes, estrella del Nether...)
            if (tier == 1) add(out, Items.DIAMOND, 8);
            if (tier == 2) add(out, Items.DIAMOND, 16);
            add(out, Items.NETHER_STAR, new int[] {1, 1, 2, 2, 3, 4}[i]);
        }
        return out;
    }

    private static void addMetal(List<Cost> out, int tier) {
        switch (tier) {
            case 1 -> add(out, Items.IRON_INGOT, 16);
            case 2 -> {
                add(out, Items.IRON_INGOT, 32);
                add(out, Items.REDSTONE, 32);
            }
            case 3 -> {
                add(out, Items.GOLD_INGOT, 32);
                add(out, Items.DIAMOND, 8);
                add(out, Items.REDSTONE_BLOCK, 4);
            }
            case 4 -> {
                add(out, Items.IRON_BLOCK, 16);
                add(out, Items.DIAMOND, 24);
                add(out, Items.GOLD_BLOCK, 8);
            }
            case 5 -> {
                add(out, Items.DIAMOND_BLOCK, 8);
                add(out, Items.EMERALD_BLOCK, 4);
                add(out, Items.GOLD_BLOCK, 16);
            }
            default -> {
                add(out, Items.DIAMOND_BLOCK, 16);
                add(out, Items.NETHERITE_INGOT, 4);
                add(out, Items.EMERALD_BLOCK, 8);
            }
        }
    }

    private Item wallItem(int tier) {
        return switch (Math.min(tier, 6)) {
            case 1 -> Items.STONE_BRICKS;
            case 2 -> Items.DEEPSLATE_BRICKS;
            case 3 -> Items.POLISHED_BLACKSTONE_BRICKS;
            case 4 -> Items.NETHER_BRICKS;
            case 5 -> Items.PRISMARINE_BRICKS;
            default -> Items.QUARTZ_BRICKS;
        };
    }

    private Item resourceItem() {
        return switch (theme) {
            case SUGAR_CANE -> Items.SUGAR_CANE;
            case BAMBOO -> Items.BAMBOO;
            case CACTUS -> Items.CACTUS;
            case PUMPKIN -> Items.PUMPKIN;
            case MELON -> Items.MELON_SLICE;
            default -> Items.AIR;
        };
    }

    private Item baseBlock() {
        return switch (theme) {
            case SUGAR_CANE, CACTUS -> Items.SAND;
            case BAMBOO -> Items.PODZOL;
            default -> Items.DIRT;
        };
    }

    private Item mobDrop() {
        return switch (theme) {
            case ZOMBIE -> Items.ROTTEN_FLESH;
            case SKELETON -> Items.BONE;
            case SPIDER -> Items.STRING;
            case CREEPER -> Items.GUNPOWDER;
            case GOLEM -> Items.IRON_INGOT;
            default -> Items.AIR;
        };
    }

    private Cost mobHeadCost() {
        return switch (theme) {
            case ZOMBIE -> new Cost(Items.ZOMBIE_HEAD, 1);
            case SKELETON -> new Cost(Items.SKELETON_SKULL, 1);
            case CREEPER -> new Cost(Items.CREEPER_HEAD, 1);
            case GOLEM -> new Cost(Items.CARVED_PUMPKIN, 1);
            default -> new Cost(Items.FERMENTED_SPIDER_EYE, 8); // la arana no tiene cabeza
        };
    }

    // ------------------------------------------------------------ PRODUCCION

    private int[] intervals() {
        if (!theme.isMob()) return new int[] {100, 70, 40};
        if (spawner) return new int[] {80, 60, 45, 35, 25, 20};
        return theme == Theme.GOLEM ? new int[] {200, 150, 110, 80, 60} : new int[] {200, 140, 100, 70};
    }

    private int[] multipliers() {
        if (!theme.isMob()) return new int[] {1, 2, 3};
        if (spawner) return new int[] {2, 3, 4, 6, 8, 12};
        return theme == Theme.GOLEM ? new int[] {1, 2, 3, 4, 6} : new int[] {1, 2, 3, 5};
    }

    /** Ticks entre cada ciclo de produccion. */
    public int interval(int tier) {
        int[] t = intervals();
        return t[Math.max(1, Math.min(tier, t.length)) - 1];
    }

    /** Multiplicador de cantidad por ciclo. */
    public int multiplier(int tier) {
        int[] t = multipliers();
        return t[Math.max(1, Math.min(tier, t.length)) - 1];
    }

    private List<Drop> drops() {
        return switch (theme) {
            case SUGAR_CANE -> List.of(new Drop(Items.SUGAR_CANE, 2, 4, 1f));
            case BAMBOO -> List.of(new Drop(Items.BAMBOO, 3, 6, 1f));
            case CACTUS -> List.of(new Drop(Items.CACTUS, 2, 4, 1f));
            case PUMPKIN -> List.of(new Drop(Items.PUMPKIN, 1, 2, 1f));
            case MELON -> List.of(new Drop(Items.MELON_SLICE, 3, 7, 1f));
            case ZOMBIE -> List.of(new Drop(Items.ROTTEN_FLESH, 0, 2, 1f), new Drop(Items.IRON_INGOT, 1, 1, 0.025f),
                    new Drop(Items.CARROT, 1, 1, 0.025f), new Drop(Items.POTATO, 1, 1, 0.025f));
            case SKELETON -> List.of(new Drop(Items.BONE, 0, 2, 1f), new Drop(Items.ARROW, 0, 2, 1f));
            case SPIDER -> List.of(new Drop(Items.STRING, 0, 2, 1f), new Drop(Items.SPIDER_EYE, 1, 1, 0.33f));
            case CREEPER -> List.of(new Drop(Items.GUNPOWDER, 0, 2, 1f));
            case GOLEM -> List.of(new Drop(Items.IRON_INGOT, 3, 5, 1f), new Drop(Items.POPPY, 0, 2, 1f));
        };
    }

    public List<ItemStack> rollDrops(int tier, RandomSource rnd) {
        List<ItemStack> out = new ArrayList<>();
        int mult = multiplier(tier);
        for (Drop d : drops()) {
            if (rnd.nextFloat() > d.chance()) continue;
            int n = (d.min() + rnd.nextInt(d.max() - d.min() + 1)) * mult;
            if (n > 0) out.add(new ItemStack(d.item(), n));
        }
        return out;
    }
}
