package com.example.granjas;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BambooLeaves;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;

/**
 * Construye las estructuras alrededor del bloque controlador (que nunca se toca).
 * Se construye FILA POR FILA, CAPA POR CAPA HACIA ARRIBA: cada tick se coloca una fila.
 */
public final class FarmBuilder {
    /** Altura del techo sobre el controlador. */
    public static final int TOP = 4;
    /** Capas: dy = -1 (suelo) hasta TOP (techo). */
    private static final int LAYERS = TOP + 2;

    private FarmBuilder() {}

    public static int lo(int size) {
        return -(size / 2);
    }

    public static int hi(int size) {
        return lo(size) + size - 1;
    }

    public static int totalCells(int size) {
        return size * size * LAYERS;
    }

    public static boolean fitsHeight(Level level, BlockPos o) {
        return !level.isOutsideBuildHeight(o.getY() - 1) && !level.isOutsideBuildHeight(o.getY() + TOP);
    }

    /**
     * No construye sobre cofres/hornos/otros controladores ni sobre bedrock.
     * Solo revisa la parte NUEVA (lo que ya construimos antes, oldSize, se respeta).
     */
    public static boolean isAreaSafe(Level level, BlockPos o, int newSize, int oldSize) {
        int lo = lo(newSize);
        int hi = hi(newSize);
        int olo = oldSize > 0 ? lo(oldSize) : 1;
        int ohi = oldSize > 0 ? hi(oldSize) : 0;
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (int dy = -1; dy <= TOP; dy++) {
            for (int dx = lo; dx <= hi; dx++) {
                for (int dz = lo; dz <= hi; dz++) {
                    if (dx == 0 && dy == 0 && dz == 0) continue;
                    if (dx >= olo && dx <= ohi && dz >= olo && dz <= ohi) continue;
                    p.set(o.getX() + dx, o.getY() + dy, o.getZ() + dz);
                    if (level.getBlockEntity(p) != null) return false;
                    if (level.getBlockState(p).getDestroySpeed(level, p) < 0) return false;
                }
            }
        }
        return true;
    }

    // ------------------------------------------------------------- Contornos

    /** Azul = tamaño del SIGUIENTE nivel. Blanco = borde limite (siempre visible). */
    public static void showOutlines(ServerLevel level, BlockPos o, FarmKind kind, int tier) {
        ring(level, o, kind.limitSize(), ParticleTypes.END_ROD, 0.9);
        if (tier < kind.maxTier()) {
            ring(level, o, kind.size(tier + 1), ParticleTypes.SOUL_FIRE_FLAME, 0.3);
        }
    }

    private static void ring(ServerLevel level, BlockPos o, int size, ParticleOptions particle, double yOff) {
        int lo = lo(size);
        int hi = hi(size);
        double y = o.getY() + yOff;
        for (int i = lo; i <= hi; i++) {
            point(level, particle, o.getX() + i + 0.5, y, o.getZ() + lo + 0.5);
            point(level, particle, o.getX() + i + 0.5, y, o.getZ() + hi + 0.5);
            if (i > lo && i < hi) {
                point(level, particle, o.getX() + lo + 0.5, y, o.getZ() + i + 0.5);
                point(level, particle, o.getX() + hi + 0.5, y, o.getZ() + i + 0.5);
            }
        }
    }

    private static void point(ServerLevel level, ParticleOptions particle, double x, double y, double z) {
        level.sendParticles(particle, x, y, z, 1, 0.0, 0.0, 0.0, 0.0);
    }

    // ------------------------------------------------------------ Construccion

    /** Coloca hasta 'max' celdas desde 'cursor'. Devuelve el nuevo cursor. */
    public static int buildStep(ServerLevel level, BlockPos o, FarmKind kind, int tier, int cursor, int max) {
        int size = kind.size(tier);
        int lo = lo(size);
        int hi = hi(size);
        int perLayer = size * size;
        int total = perLayer * LAYERS;
        int end = Math.min(total, cursor + max);
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (int i = cursor; i < end; i++) {
            int dy = i / perLayer - 1;
            int rem = i % perLayer;
            int dx = lo + rem % size;
            int dz = lo + rem / size;
            BlockState s = stateAt(kind, tier, dx, dy, dz, lo, hi);
            if (s == null) continue;
            p.set(o.getX() + dx, o.getY() + dy, o.getZ() + dz);
            level.setBlock(p, s, s.isAir() ? Block.UPDATE_CLIENTS : Block.UPDATE_ALL);
        }
        return end;
    }

    /** Que bloque va en cada posicion (null = no tocar: es el controlador). */
    public static BlockState stateAt(FarmKind kind, int tier, int dx, int dy, int dz, int lo, int hi) {
        if (dx == 0 && dy == 0 && dz == 0) return null;
        boolean mob = kind.theme.isMob();
        boolean corner = (dx == lo || dx == hi) && (dz == lo || dz == hi);
        int pillarH = mob ? TOP : 2;
        if (corner && dy >= 0 && dy < pillarH) return pillar(tier);
        if (corner && !mob && dy == pillarH) return Blocks.TORCH.defaultBlockState();
        return mob ? mobState(kind, tier, dx, dy, dz, lo, hi) : resourceState(kind.theme, dx, dy, dz);
    }

    private static BlockState pillar(int tier) {
        Block b = switch (Math.min(tier, 6)) {
            case 1 -> Blocks.CHISELED_STONE_BRICKS;
            case 2 -> Blocks.IRON_BLOCK;
            case 3 -> Blocks.GOLD_BLOCK;
            case 4 -> Blocks.DIAMOND_BLOCK;
            case 5 -> Blocks.EMERALD_BLOCK;
            default -> Blocks.NETHERITE_BLOCK;
        };
        return b.defaultBlockState();
    }

    private static BlockState wallBlock(int tier) {
        Block b = switch (Math.min(tier, 6)) {
            case 1 -> Blocks.STONE_BRICKS;
            case 2 -> Blocks.DEEPSLATE_BRICKS;
            case 3 -> Blocks.POLISHED_BLACKSTONE_BRICKS;
            case 4 -> Blocks.NETHER_BRICKS;
            case 5 -> Blocks.PRISMARINE_BRICKS;
            default -> Blocks.QUARTZ_BRICKS;
        };
        return b.defaultBlockState();
    }

    private static BlockState resourceState(FarmKind.Theme theme, int dx, int dy, int dz) {
        BlockState air = Blocks.AIR.defaultBlockState();
        boolean center = dx == 0 && dz == 0;
        switch (theme) {
            case SUGAR_CANE: {
                // Filas de agua cada 3: toda la arena queda pegada al agua
                boolean water = Math.floorMod(dz, 3) == 0;
                if (dy == -1) return water ? Blocks.WATER.defaultBlockState() : Blocks.SAND.defaultBlockState();
                if (dy >= 0 && dy < 3 && !water) return Blocks.SUGAR_CANE.defaultBlockState();
                return air;
            }
            case BAMBOO: {
                if (dy == -1) return Blocks.PODZOL.defaultBlockState();
                if (((dx + dz) & 1) == 0 && !center && dy >= 0 && dy < 4) {
                    BlockState s = Blocks.BAMBOO.defaultBlockState();
                    if (dy == 3) s = s.setValue(BlockStateProperties.BAMBOO_LEAVES, BambooLeaves.LARGE);
                    else if (dy == 2) s = s.setValue(BlockStateProperties.BAMBOO_LEAVES, BambooLeaves.SMALL);
                    return s;
                }
                return air;
            }
            case CACTUS: {
                if (dy == -1) return Blocks.SAND.defaultBlockState();
                if (((dx + dz) & 1) == 0 && !center && dy >= 0 && dy < 3) return Blocks.CACTUS.defaultBlockState();
                return air;
            }
            case PUMPKIN:
            case MELON: {
                boolean melon = theme == FarmKind.Theme.MELON;
                boolean evenRow = (dz & 1) == 0;
                // Un agua cada 9 bloques riega todo alrededor (radio 4)
                boolean waterCell = Math.floorMod(dx, 9) == 0 && Math.floorMod(dz, 9) == 0;
                if (dy == -1) {
                    if (waterCell) return Blocks.WATER.defaultBlockState();
                    if (!evenRow) return Blocks.DIRT_PATH.defaultBlockState();
                    if ((dx & 1) != 0) {
                        return Blocks.FARMLAND.defaultBlockState().setValue(BlockStateProperties.MOISTURE, 7);
                    }
                    return Blocks.DIRT.defaultBlockState();
                }
                if (dy == 0 && evenRow && !waterCell) {
                    if ((dx & 1) != 0) {
                        return (melon ? Blocks.MELON_STEM : Blocks.PUMPKIN_STEM).defaultBlockState()
                                .setValue(BlockStateProperties.AGE_7, 7);
                    }
                    return (melon ? Blocks.MELON : Blocks.PUMPKIN).defaultBlockState();
                }
                return air;
            }
            default:
                return air;
        }
    }

    private static BlockState decor(FarmKind.Theme theme) {
        switch (theme) {
            case ZOMBIE:
                return Blocks.ZOMBIE_HEAD.defaultBlockState();
            case SKELETON:
                return Blocks.SKELETON_SKULL.defaultBlockState();
            case CREEPER:
                return Blocks.CREEPER_HEAD.defaultBlockState();
            case GOLEM:
                return Blocks.CARVED_PUMPKIN.defaultBlockState();
            default:
                return Blocks.COBWEB.defaultBlockState();
        }
    }

    private static BlockState mobState(FarmKind kind, int tier, int dx, int dy, int dz, int lo, int hi) {
        BlockState wall = wallBlock(tier);
        BlockState air = Blocks.AIR.defaultBlockState();
        if (dy == -1 || dy == TOP) return wall; // suelo y techo
        boolean edge = dx == lo || dx == hi || dz == lo || dz == hi;
        if (edge) {
            if (dx == 0 && dz == hi && dy <= 1) return air; // puerta
            return wall;
        }
        // Columnas interiores cada 8 bloques (soportan el techo), lejos del controlador y la jaula
        if (Math.floorMod(dx, 8) == 0 && Math.floorMod(dz, 8) == 0 && (Math.abs(dx) > 2 || Math.abs(dz) > 4)) {
            return wall;
        }
        // Jaula de barrotes con la "cabeza" del mob (granjas de spawner)
        if (kind.spawner && dx >= -1 && dx <= 1 && dz >= -3 && dz <= -1) {
            boolean centerCell = dx == 0 && dz == -2;
            if (dy == 0) return centerCell ? decor(kind.theme) : Blocks.IRON_BARS.defaultBlockState();
            if (dy == 1) return centerCell ? air : Blocks.IRON_BARS.defaultBlockState();
            if (dy == 2) return Blocks.IRON_BARS.defaultBlockState();
        }
        return air;
    }
}
