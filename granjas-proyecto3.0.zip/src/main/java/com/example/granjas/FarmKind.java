package com.example.granjas;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * Las 40 granjas del mod (20 naturales + 20 de spawner).
 * Aqui estan los TAMAÑOS, COSTOS por nivel, VELOCIDAD y DROPS. Ajusta los numeros a tu gusto.
 */
public enum FarmKind {
    SUGAR_CANE_FARM("sugar_cane_farm", Theme.SUGAR_CANE, false),
    BAMBOO_FARM("bamboo_farm", Theme.BAMBOO, false),
    CACTUS_FARM("cactus_farm", Theme.CACTUS, false),
    PUMPKIN_FARM("pumpkin_farm", Theme.PUMPKIN, false),
    MELON_FARM("melon_farm", Theme.MELON, false),
    NETHER_WART_FARM("nether_wart_farm", Theme.NETHER_WART, false),
    ZOMBIE_FARM("zombie_farm", Theme.ZOMBIE, false),
    SKELETON_FARM("skeleton_farm", Theme.SKELETON, false),
    SPIDER_FARM("spider_farm", Theme.SPIDER, false),
    CREEPER_FARM("creeper_farm", Theme.CREEPER, false),
    GOLEM_FARM("golem_farm", Theme.GOLEM, false),
    PIGLIN_FARM("piglin_farm", Theme.PIGLIN, false),
    ENDERMAN_FARM("enderman_farm", Theme.ENDERMAN, false),
    WITCH_FARM("witch_farm", Theme.WITCH, false),
    SLIME_FARM("slime_farm", Theme.SLIME, false),
    GUARDIAN_FARM("guardian_farm", Theme.GUARDIAN, false),
    DROWNED_FARM("drowned_farm", Theme.DROWNED, false),
    WITHER_SKELETON_FARM("wither_skeleton_farm", Theme.WITHER_SKELETON, false),
    COW_FARM("cow_farm", Theme.COW, false),
    SHEEP_FARM("sheep_farm", Theme.SHEEP, false),
    ZOMBIE_SPAWNER_FARM("zombie_spawner_farm", Theme.ZOMBIE, true),
    SKELETON_SPAWNER_FARM("skeleton_spawner_farm", Theme.SKELETON, true),
    SPIDER_SPAWNER_FARM("spider_spawner_farm", Theme.SPIDER, true),
    CREEPER_SPAWNER_FARM("creeper_spawner_farm", Theme.CREEPER, true),
    GOLEM_SPAWNER_FARM("golem_spawner_farm", Theme.GOLEM, true),
    PIGLIN_SPAWNER_FARM("piglin_spawner_farm", Theme.PIGLIN, true),
    ENDERMAN_SPAWNER_FARM("enderman_spawner_farm", Theme.ENDERMAN, true),
    WITCH_SPAWNER_FARM("witch_spawner_farm", Theme.WITCH, true),
    SLIME_SPAWNER_FARM("slime_spawner_farm", Theme.SLIME, true),
    GUARDIAN_SPAWNER_FARM("guardian_spawner_farm", Theme.GUARDIAN, true),
    DROWNED_SPAWNER_FARM("drowned_spawner_farm", Theme.DROWNED, true),
    WITHER_SKELETON_SPAWNER_FARM("wither_skeleton_spawner_farm", Theme.WITHER_SKELETON, true),
    COW_SPAWNER_FARM("cow_spawner_farm", Theme.COW, true),
    SHEEP_SPAWNER_FARM("sheep_spawner_farm", Theme.SHEEP, true),
    BLAZE_SPAWNER_FARM("blaze_spawner_farm", Theme.BLAZE, true),
    CAVE_SPIDER_SPAWNER_FARM("cave_spider_spawner_farm", Theme.CAVE_SPIDER, true),
    MAGMA_CUBE_SPAWNER_FARM("magma_cube_spawner_farm", Theme.MAGMA_CUBE, true),
    CHICKEN_SPAWNER_FARM("chicken_spawner_farm", Theme.CHICKEN, true),
    PIG_SPAWNER_FARM("pig_spawner_farm", Theme.PIG, true),
    GHAST_SPAWNER_FARM("ghast_spawner_farm", Theme.GHAST, true);

    /** Bloques extra del borde limite a cada lado, mas alla del tamaño final. */
    public static final int LIMIT_MARGIN = 2;

    public enum Theme {
        // Recursos
        SUGAR_CANE, BAMBOO, CACTUS, PUMPKIN, MELON, NETHER_WART,
        // Mobs
        ZOMBIE, SKELETON, SPIDER, CREEPER, GOLEM, PIGLIN, ENDERMAN, WITCH, SLIME, GUARDIAN, DROWNED,
        WITHER_SKELETON, COW, SHEEP, BLAZE, CAVE_SPIDER, MAGMA_CUBE, CHICKEN, PIG, GHAST;

        public boolean isMob() {
            return ordinal() >= ZOMBIE.ordinal();
        }

        /** Item principal del costo (la "firma" de la granja). */
        Item costItem() {
            return switch (this) {
                case SUGAR_CANE -> Items.SUGAR_CANE;
                case BAMBOO -> Items.BAMBOO;
                case CACTUS -> Items.CACTUS;
                case PUMPKIN -> Items.PUMPKIN;
                case MELON -> Items.MELON_SLICE;
                case NETHER_WART -> Items.NETHER_WART;
                case ZOMBIE, DROWNED -> Items.ROTTEN_FLESH;
                case SKELETON -> Items.BONE;
                case SPIDER, CAVE_SPIDER -> Items.STRING;
                case CREEPER -> Items.GUNPOWDER;
                case GOLEM -> Items.IRON_INGOT;
                case PIGLIN -> Items.GOLD_INGOT;
                case ENDERMAN -> Items.ENDER_PEARL;
                case WITCH -> Items.REDSTONE;
                case SLIME -> Items.SLIME_BALL;
                case GUARDIAN -> Items.PRISMARINE_SHARD;
                case WITHER_SKELETON -> Items.COAL;
                case COW -> Items.LEATHER;
                case SHEEP -> Items.WHITE_WOOL;
                case BLAZE -> Items.BLAZE_ROD;
                case MAGMA_CUBE -> Items.MAGMA_CREAM;
                case CHICKEN -> Items.FEATHER;
                case PIG -> Items.PORKCHOP;
                case GHAST -> Items.GHAST_TEAR;
                default -> Items.AIR;
            };
        }

        /** Bloque base de las granjas de recursos. */
        Item baseItem() {
            return switch (this) {
                case SUGAR_CANE, CACTUS -> Items.SAND;
                case BAMBOO -> Items.PODZOL;
                case NETHER_WART -> Items.SOUL_SAND;
                default -> Items.DIRT;
            };
        }

        /** Items raros cuestan menos cantidad. */
        double costScale() {
            return switch (this) {
                case ENDERMAN, GHAST -> 0.25;
                case BLAZE, MAGMA_CUBE -> 0.5;
                case GUARDIAN -> 0.75;
                default -> 1.0;
            };
        }

        /** Item especial que piden las granjas de spawner en el nivel 1. */
        Cost headCost() {
            return switch (this) {
                case ZOMBIE -> new Cost(Items.ZOMBIE_HEAD, 1);
                case SKELETON -> new Cost(Items.SKELETON_SKULL, 1);
                case CREEPER -> new Cost(Items.CREEPER_HEAD, 1);
                case WITHER_SKELETON -> new Cost(Items.WITHER_SKELETON_SKULL, 1);
                case GOLEM -> new Cost(Items.CARVED_PUMPKIN, 1);
                case SPIDER, CAVE_SPIDER -> new Cost(Items.FERMENTED_SPIDER_EYE, 8);
                case PIGLIN -> new Cost(Items.GOLD_BLOCK, 2);
                case ENDERMAN -> new Cost(Items.ENDER_EYE, 4);
                case WITCH -> new Cost(Items.BREWING_STAND, 1);
                case SLIME -> new Cost(Items.SLIME_BLOCK, 4);
                case GUARDIAN -> new Cost(Items.SEA_LANTERN, 4);
                case DROWNED -> new Cost(Items.SPONGE, 2);
                case COW -> new Cost(Items.MILK_BUCKET, 1);
                case SHEEP -> new Cost(Items.SHEARS, 1);
                case PIG -> new Cost(Items.SADDLE, 1);
                case CHICKEN -> new Cost(Items.HAY_BLOCK, 4);
                case BLAZE -> new Cost(Items.BLAZE_POWDER, 16);
                case MAGMA_CUBE -> new Cost(Items.MAGMA_BLOCK, 8);
                case GHAST -> new Cost(Items.FIRE_CHARGE, 8);
                default -> new Cost(Items.AIR, 0);
            };
        }

        List<Drop> drops() {
            return switch (this) {
                case SUGAR_CANE -> List.of(new Drop(Items.SUGAR_CANE, 2, 4, 1f));
                case BAMBOO -> List.of(new Drop(Items.BAMBOO, 3, 6, 1f));
                case CACTUS -> List.of(new Drop(Items.CACTUS, 2, 4, 1f));
                case PUMPKIN -> List.of(new Drop(Items.PUMPKIN, 1, 2, 1f));
                case MELON -> List.of(new Drop(Items.MELON_SLICE, 3, 7, 1f));
                case NETHER_WART -> List.of(new Drop(Items.NETHER_WART, 2, 4, 1f));
                case ZOMBIE -> List.of(new Drop(Items.ROTTEN_FLESH, 0, 2, 1f), new Drop(Items.IRON_INGOT, 1, 1, 0.025f),
                        new Drop(Items.CARROT, 1, 1, 0.025f), new Drop(Items.POTATO, 1, 1, 0.025f));
                case SKELETON -> List.of(new Drop(Items.BONE, 0, 2, 1f), new Drop(Items.ARROW, 0, 2, 1f));
                case SPIDER, CAVE_SPIDER -> List.of(new Drop(Items.STRING, 0, 2, 1f), new Drop(Items.SPIDER_EYE, 1, 1, 0.33f));
                case CREEPER -> List.of(new Drop(Items.GUNPOWDER, 0, 2, 1f));
                case GOLEM -> List.of(new Drop(Items.IRON_INGOT, 3, 5, 1f), new Drop(Items.POPPY, 0, 2, 1f));
                case PIGLIN -> List.of(new Drop(Items.GOLD_NUGGET, 1, 3, 1f), new Drop(Items.ROTTEN_FLESH, 0, 1, 1f),
                        new Drop(Items.GOLD_INGOT, 1, 1, 0.025f));
                case ENDERMAN -> List.of(new Drop(Items.ENDER_PEARL, 0, 1, 1f));
                case WITCH -> List.of(new Drop(Items.REDSTONE, 0, 3, 1f), new Drop(Items.GLOWSTONE_DUST, 0, 2, 1f),
                        new Drop(Items.SUGAR, 0, 2, 1f), new Drop(Items.STICK, 0, 2, 1f), new Drop(Items.GUNPOWDER, 0, 1, 1f));
                case SLIME -> List.of(new Drop(Items.SLIME_BALL, 0, 2, 1f));
                case GUARDIAN -> List.of(new Drop(Items.PRISMARINE_SHARD, 0, 2, 1f),
                        new Drop(Items.PRISMARINE_CRYSTALS, 1, 1, 0.33f), new Drop(Items.COD, 0, 1, 1f));
                case DROWNED -> List.of(new Drop(Items.ROTTEN_FLESH, 0, 2, 1f), new Drop(Items.COPPER_INGOT, 1, 1, 0.11f),
                        new Drop(Items.NAUTILUS_SHELL, 1, 1, 0.03f));
                case WITHER_SKELETON -> List.of(new Drop(Items.COAL, 0, 1, 1f), new Drop(Items.BONE, 0, 2, 1f),
                        new Drop(Items.WITHER_SKELETON_SKULL, 1, 1, 0.025f));
                case COW -> List.of(new Drop(Items.LEATHER, 0, 2, 1f), new Drop(Items.BEEF, 1, 3, 1f));
                case SHEEP -> List.of(new Drop(Items.WHITE_WOOL, 1, 1, 1f), new Drop(Items.MUTTON, 1, 2, 1f));
                case BLAZE -> List.of(new Drop(Items.BLAZE_ROD, 0, 1, 1f));
                case MAGMA_CUBE -> List.of(new Drop(Items.MAGMA_CREAM, 0, 1, 1f));
                case CHICKEN -> List.of(new Drop(Items.FEATHER, 0, 2, 1f), new Drop(Items.CHICKEN, 1, 1, 1f),
                        new Drop(Items.EGG, 0, 1, 1f));
                case PIG -> List.of(new Drop(Items.PORKCHOP, 1, 3, 1f));
                case GHAST -> List.of(new Drop(Items.GHAST_TEAR, 0, 1, 1f), new Drop(Items.GUNPOWDER, 0, 2, 1f));
                default -> List.of();
            };
        }
    }

    /** Un material requerido. */
    public record Cost(Item item, int count) {
        public ItemStack icon() {
            return new ItemStack(item);
        }
    }

    /** Un drop de produccion. */
    public record Drop(Item item, int min, int max, float chance) {}

    public final String id;
    public final Theme theme;
    public final boolean spawner;

    FarmKind(String id, Theme theme, boolean spawner) {
        this.id = id;
        this.theme = theme;
        this.spawner = spawner;
    }

    /** Las granjas de mobs del Nether solo se pueden colocar en el Nether. */
    public boolean requiresNether() {
        switch (theme) {
            case PIGLIN:
            case WITHER_SKELETON:
            case BLAZE:
            case MAGMA_CUBE:
            case GHAST:
                return true;
            default:
                return false;
        }
    }

    public Component displayName() {
        return Component.translatable("block." + GranjasMod.MOD_ID + "." + id);
    }

    // ------------------------------------------------------------------ TAMAÑOS

    /** Lado del cuadrado de la granja en cada nivel (el numero de niveles = largo de esta lista). */
    private int[] sizes() {
        if (!theme.isMob()) return new int[] {20, 25, 40};
        if (theme == Theme.GOLEM) {
            return spawner ? new int[] {25, 32, 40, 52, 64, 72} : new int[] {25, 32, 40, 50, 60};
        }
        return spawner ? new int[] {20, 25, 32, 40, 52, 64} : new int[] {20, 25, 40, 50};
    }

    public int maxTier() {
        return sizes().length;
    }

    public int size(int tier) {
        int[] s = sizes();
        return s[Math.max(1, Math.min(tier, s.length)) - 1];
    }

    /** Lado del borde limite (siempre visible): tamaño final + margen a cada lado. */
    public int limitSize() {
        return size(maxTier()) + 2 * LIMIT_MARGIN;
    }

    // ------------------------------------------------------------------ COSTOS

    private static void add(List<Cost> out, Item item, int n) {
        for (int i = 0; i < out.size(); i++) {
            if (out.get(i).item() == item) {
                out.set(i, new Cost(item, out.get(i).count() + n));
                return;
            }
        }
        out.add(new Cost(item, n));
    }

    private int dropCount(int base) {
        int n = (int) Math.round(base * theme.costScale() / 8.0) * 8;
        return Math.max(8, n);
    }

    /** Materiales para CONSTRUIR/MEJORAR hasta el nivel indicado (1..maxTier). */
    public List<Cost> cost(int tier) {
        if (tier < 1 || tier > maxTier()) return List.of();
        List<Cost> out = new ArrayList<>();
        int i = tier - 1;

        if (!theme.isMob()) {
            add(out, theme.baseItem(), new int[] {128, 192, 256}[i]);
            add(out, theme.costItem(), new int[] {16, 48, 128}[i]);
            switch (tier) {
                case 1 -> add(out, Items.IRON_INGOT, 8);
                case 2 -> {
                    add(out, Items.IRON_INGOT, 24);
                    add(out, Items.REDSTONE, 32);
                    add(out, Items.GLASS, 32);
                }
                default -> {
                    add(out, Items.GOLD_INGOT, 32);
                    add(out, Items.DIAMOND, 12);
                    add(out, Items.REDSTONE_BLOCK, 8);
                }
            }
            return out;
        }

        add(out, wallItem(tier), new int[] {128, 192, 256, 256, 256, 256}[i]);
        add(out, theme.costItem(),
                dropCount((spawner ? new int[] {64, 128, 192, 256, 256, 256} : new int[] {32, 64, 128, 192, 256, 256})[i]));
        if (spawner && tier == 1) {
            add(out, Items.IRON_BARS, 16);
            Cost head = theme.headCost();
            add(out, head.item(), head.count());
        }
        addMetal(out, tier);
        if (spawner) {
            // Spawner: caro de verdad (diamantes, estrella del Nether...)
            if (tier == 1) add(out, Items.DIAMOND, 8);
            if (tier == 2) add(out, Items.DIAMOND, 16);
            add(out, Items.NETHER_STAR, new int[] {1, 1, 2, 2, 3, 4}[i]);
        }
        return out;
    }

    private static void addMetal(List<Cost> out, int tier) {
        switch (tier) {
            case 1 -> add(out, Items.IRON_INGOT, 16);
            case 2 -> {
                add(out, Items.IRON_INGOT, 32);
                add(out, Items.REDSTONE, 32);
            }
            case 3 -> {
                add(out, Items.GOLD_INGOT, 32);
                add(out, Items.DIAMOND, 8);
                add(out, Items.REDSTONE_BLOCK, 4);
            }
            case 4 -> {
                add(out, Items.IRON_BLOCK, 16);
                add(out, Items.DIAMOND, 24);
                add(out, Items.GOLD_BLOCK, 8);
            }
            case 5 -> {
                add(out, Items.DIAMOND_BLOCK, 8);
                add(out, Items.EMERALD_BLOCK, 4);
                add(out, Items.GOLD_BLOCK, 16);
            }
            default -> {
                add(out, Items.DIAMOND_BLOCK, 16);
                add(out, Items.NETHERITE_INGOT, 4);
                add(out, Items.EMERALD_BLOCK, 8);
            }
        }
    }

    private Item wallItem(int tier) {
        return switch (Math.min(tier, 6)) {
            case 1 -> Items.STONE_BRICKS;
            case 2 -> Items.DEEPSLATE_BRICKS;
            case 3 -> Items.POLISHED_BLACKSTONE_BRICKS;
            case 4 -> Items.NETHER_BRICKS;
            case 5 -> Items.PRISMARINE_BRICKS;
            default -> Items.QUARTZ_BRICKS;
        };
    }

    // ------------------------------------------------------------ PRODUCCION

    private int[] intervals() {
        if (!theme.isMob()) return new int[] {100, 70, 40};
        if (spawner) return new int[] {80, 60, 45, 35, 25, 20};
        return theme == Theme.GOLEM ? new int[] {200, 150, 110, 80, 60} : new int[] {200, 140, 100, 70};
    }

    private int[] multipliers() {
        if (!theme.isMob()) return new int[] {1, 2, 3};
        if (spawner) return new int[] {2, 3, 4, 6, 8, 12};
        return theme == Theme.GOLEM ? new int[] {1, 2, 3, 4, 6} : new int[] {1, 2, 3, 5};
    }

    /** Ticks entre cada ciclo de produccion. */
    public int interval(int tier) {
        int[] t = intervals();
        return t[Math.max(1, Math.min(tier, t.length)) - 1];
    }

    /** Multiplicador de cantidad por ciclo. */
    public int multiplier(int tier) {
        int[] t = multipliers();
        return t[Math.max(1, Math.min(tier, t.length)) - 1];
    }

    public List<ItemStack> rollDrops(int tier, RandomSource rnd) {
        List<ItemStack> out = new ArrayList<>();
        int mult = multiplier(tier);
        for (Drop d : theme.drops()) {
            if (rnd.nextFloat() > d.chance()) continue;
            int n = (d.min() + rnd.nextInt(d.max() - d.min() + 1)) * mult;
            if (n > 0) out.add(new ItemStack(d.item(), n));
        }
        return out;
    }
}
