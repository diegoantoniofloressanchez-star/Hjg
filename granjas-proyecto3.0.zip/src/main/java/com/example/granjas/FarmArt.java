package com.example.granjas;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/** Pixel art 9x9 de cada granja (se construye enfrente) + paleta de bloques. ARCHIVO GENERADO. */
public final class FarmArt {
    private FarmArt() {}

    public static String[] get(FarmKind.Theme theme) {
        switch (theme) {
            case SUGAR_CANE: return new String[] {".n..n..n.", ".u..u..u.", "nn..n..nn", ".n..n..n.", ".u..u..u.", ".n..n..n.", ".n..n..n.", ".u..u..u.", ".n..n..n."};
            case BAMBOO: return new String[] {"..u...u..", "..n...n..", "..n...n..", ".uuu.uuu.", "..n...n..", "..n...n..", ".uuu.uuu.", "..n...n..", "..n...n.."};
            case CACTUS: return new String[] {"....n....", "..n.n....", "..n.n.n..", "..nnn.n..", "....nnn..", "....n....", "....n....", "....n....", "...ttt..."};
            case PUMPKIN: return new String[] {"....n....", ".ooooooo.", "ooooooooo", "oo.ooo.oo", "ooooooooo", "oo.....oo", "ooo.o.ooo", ".ooooooo.", "........."};
            case MELON: return new String[] {".........", ".rrrrrrr.", "rr.rr.rrr", "rrrrrrrrr", ".uuuuuuu.", "..nnnnn..", "...nnn...", ".........", "........."};
            case NETHER_WART: return new String[] {".........", "..r...r..", ".rrr.rrr.", ".rmr.rmr.", "..r...r..", ".rrrrrrr.", "rrmrrrmrr", ".rrrrrrr.", "..t...t.."};
            case ZOMBIE: return new String[] {"nnnnnnnnn", "nnnnnnnnn", "nbbnnnbbn", "nbbnnnbbn", "nnnnunnnn", "nnnuuunnn", "nnn...nnn", "nnn.n.nnn", "nnnnnnnnn"};
            case SKELETON: return new String[] {".wwwwwww.", "wwwwwwwww", "wwwwwwwww", "w..www..w", "w..www..w", "wwwwwwwww", ".wwg.gww.", ".wwwwwww.", "..w.w.w.."};
            case SPIDER: return new String[] {"g.......g", ".g.....g.", "..g.g.g..", "..ggggg..", "ggggggggg", "..grgrg..", "..ggggg..", ".g.g.g.g.", "g.......g"};
            case CREEPER: return new String[] {"nnnnnnnnn", "nnnnnnnnn", "n..nnn..n", "n..nnn..n", "nnnn.nnnn", "nnn...nnn", "nnn...nnn", "nnn.n.nnn", "nnnnnnnnn"};
            case GOLEM: return new String[] {".........", "..lllll..", ".lwwwwwl.", ".lwIIIIg.", ".lIIIIIg.", "..gIIIgg.", "...ggggg.", ".........", "........."};
            case PIGLIN: return new String[] {".........", "..yyyyy..", ".yyyyyyo.", ".yyDDDDo.", ".yDDDDDo.", "..oDDDoo.", "...ooooo.", ".........", "........."};
            case ENDERMAN: return new String[] {"...ccc...", "..cuuuc..", ".cuuuuucc", ".cuuuccnc", ".ccccccnc", ".ccccnnnc", "..ccnnnc.", "...ccc...", "........."};
            case WITCH: return new String[] {"....p....", "...ppp...", "..ppppp..", "..pyyypp.", "...ppp...", "...ppp...", ".ppppppp.", "ppppppppp", "........."};
            case SLIME: return new String[] {".........", "..uuuuu..", ".uuuuuuu.", ".unnuunn.", ".unnuunn.", ".uuuuuuu.", ".uu...uu.", "..uuuuu..", "........."};
            case GUARDIAN: return new String[] {".......ac", "......acc", ".....acc.", "....acc..", "...acc...", "..acc....", ".acc.....", "acc......", "cc......."};
            case DROWNED: return new String[] {".c..c..c.", ".c..c..c.", ".c.ccc.c.", ".ccccccc.", "...ccc...", "....t....", "....t....", "....t....", "....t...."};
            case WITHER_SKELETON: return new String[] {".ggggggg.", "ggggggggg", "ggggggggg", "g..ggg..g", "g..ggg..g", "ggggggggg", ".ggl.lgg.", ".ggggggg.", "..g.g.g.."};
            case COW: return new String[] {".w.....w.", ".ttttttt.", "ttttttttt", "tw.ttt.wt", "ttttttttt", ".twwwwwt.", ".twk.kwt.", ".twwwwwt.", "..ttttt.."};
            case SHEEP: return new String[] {".wwwwwww.", "wwwwwwwww", "wwwlllwww", "wwlg.glww", "wwlllllww", "wwwlklwww", ".wwwlwww.", "..wwwww..", "........."};
            case BLAZE: return new String[] {"....o....", "...ooo...", "..ooyoo..", "..oyyyo..", ".ooyyyoo.", ".ooyyyoo.", "..ooyoo..", "...ooo...", "....o...."};
            case CAVE_SPIDER: return new String[] {".........", "c.......c", ".c.ccc.c.", "..ccccc..", "cccrcrccc", "..ccccc..", ".c.ccc.c.", "c.......c", "........."};
            case MAGMA_CUBE: return new String[] {".........", ".ooooooo.", ".orrrrro.", ".or.r.ro.", ".orrrrro.", ".oryyyro.", ".orrrrro.", ".ooooooo.", "........."};
            case CHICKEN: return new String[] {"...r.r...", "..rrrrr..", ".wwwwwww.", ".w.www.w.", ".wwwwwww.", "..wyyyw..", "..wyyyw..", "...wrw...", "........."};
            case PIG: return new String[] {".k.....k.", "kkkkkkkkk", "kkkkkkkkk", "kk.kkk.kk", "kkkkkkkkk", "kkmmmmmkk", "kkm.m.mkk", "kkmmmmmkk", ".kkkkkkk."};
            case GHAST: return new String[] {"wwwwwwwww", "wwwwwwwww", "wllwwwllw", "wwwwwwwww", "wwwwwwwww", "wwwwwwwww", "wwwlllwww", "wwwlllwww", "wwwwwwwww"};
            default: return new String[] {"........." , ".........", ".........", ".........", ".........", ".........", ".........", ".........", "........."};
        }
    }

    public static BlockState pixel(char c) {
        Block b;
        switch (c) {
            case '.': b = Blocks.BLACK_CONCRETE; break;
            case 'w': b = Blocks.WHITE_CONCRETE; break;
            case 'l': b = Blocks.LIGHT_GRAY_CONCRETE; break;
            case 'g': b = Blocks.GRAY_CONCRETE; break;
            case 'r': b = Blocks.RED_CONCRETE; break;
            case 'o': b = Blocks.ORANGE_CONCRETE; break;
            case 'y': b = Blocks.YELLOW_CONCRETE; break;
            case 'u': b = Blocks.LIME_CONCRETE; break;
            case 'n': b = Blocks.GREEN_CONCRETE; break;
            case 'c': b = Blocks.CYAN_CONCRETE; break;
            case 'a': b = Blocks.LIGHT_BLUE_CONCRETE; break;
            case 'b': b = Blocks.BLUE_CONCRETE; break;
            case 'p': b = Blocks.PURPLE_CONCRETE; break;
            case 'm': b = Blocks.MAGENTA_CONCRETE; break;
            case 'k': b = Blocks.PINK_CONCRETE; break;
            case 't': b = Blocks.BROWN_CONCRETE; break;
            case 'I': b = Blocks.IRON_BLOCK; break;
            case 'D': b = Blocks.GOLD_BLOCK; break;
            default: b = Blocks.BLACK_CONCRETE; break;
        }
        return b.defaultBlockState();
    }

    /** Color ARGB de cada pixel (para dibujar el arte en el libro). ARCHIVO GENERADO. */
    public static int rgb(char c) {
        switch (c) {
            case '.': return 0xFF0C0C0E;
            case 'w': return 0xFFEBEBEB;
            case 'l': return 0xFFA0A0A0;
            case 'g': return 0xFF46464B;
            case 'r': return 0xFFB42828;
            case 'o': return 0xFFE67814;
            case 'y': return 0xFFF0D228;
            case 'u': return 0xFF6EC832;
            case 'n': return 0xFF2D6E23;
            case 'c': return 0xFF1E8C96;
            case 'a': return 0xFF6EC8E6;
            case 'b': return 0xFF283CAA;
            case 'p': return 0xFF6E2896;
            case 'm': return 0xFFBE32AA;
            case 'k': return 0xFFF096AA;
            case 't': return 0xFF6E4628;
            case 'I': return 0xFFDCDCDC;
            case 'D': return 0xFFFADC46;
            default: return 0xFF0C0C0E;
        }
    }
}
