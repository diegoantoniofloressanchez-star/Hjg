package com.example.granjas;

import com.example.granjas.client.ClientHooks;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

/** Libro de guia: clic derecho abre la guia de todas las granjas. */
public class GuideBookItem extends Item {
    public GuideBookItem(Item.Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (level.isClientSide()) {
            ClientHooks.openGuide();
        }
        return InteractionResult.SUCCESS;
    }
}
