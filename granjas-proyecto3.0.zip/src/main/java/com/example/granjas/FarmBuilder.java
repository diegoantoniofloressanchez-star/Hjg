package com.example.granjas;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BambooLeaves;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;

/**
 * Construye las estructuras alrededor del bloque controlador (que nunca se toca) y un
 * letrero con PIXEL ART enfrente. Se construye FILA POR FILA, CAPA POR CAPA HACIA ARRIBA.
 */
public final class FarmBuilder {
    /** Altura del techo sobre el controlador. */
    public static final int TOP = 4;
    /** Capas de la estructura: dy = -1 (suelo) hasta TOP + 1 (lamparas del techo). */
    private static final int LAYERS = TOP + 3;

    /** Letrero de pixel art: marco de 11x11 con arte de 9x9 dentro. */
    private static final int BB_W = 11;
    private static final int BB_H = 11;
    private static final int BB = BB_W * BB_H;

    private FarmBuilder() {}

    public static int lo(int size) {
        return -(size / 2);
    }

    public static int hi(int size) {
        return lo(size) + size - 1;
    }

    /** Celdas totales de la construccion de un nivel: limpiar letrero viejo + estructura + letrero nuevo. */
    public static int totalCells(FarmKind kind, int tier) {
        int size = kind.size(tier);
        return (tier > 1 ? BB : 0) + size * size * LAYERS + BB;
    }

    public static boolean fitsHeight(Level level, BlockPos o) {
        return !level.isOutsideBuildHeight(o.getY() - 1) && !level.isOutsideBuildHeight(o.getY() + BB_H);
    }

    /**
     * No construye sobre cofres/hornos/otros controladores ni sobre bedrock.
     * Solo revisa la parte NUEVA (lo que ya construimos antes, oldSize, se respeta).
     */
    public static boolean isAreaSafe(Level level, BlockPos o, int newSize, int oldSize) {
        int lo = lo(newSize);
        int hi = hi(newSize);
        int olo = oldSize > 0 ? lo(oldSize) : 1;
        int ohi = oldSize > 0 ? hi(oldSize) : 0;
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (int dy = -1; dy <= TOP + 1; dy++) {
            for (int dx = lo; dx <= hi; dx++) {
                for (int dz = lo; dz <= hi; dz++) {
                    if (dx == 0 && dy == 0 && dz == 0) continue;
                    if (dx >= olo && dx <= ohi && dz >= olo && dz <= ohi) continue;
                    p.set(o.getX() + dx, o.getY() + dy, o.getZ() + dz);
                    if (level.getBlockEntity(p) != null) return false;
                    if (level.getBlockState(p).getDestroySpeed(level, p) < 0) return false;
                }
            }
        }
        // Zona del letrero
        for (int gy = 0; gy < BB_H; gy++) {
            for (int gx = 0; gx < BB_W; gx++) {
                p.set(o.getX() + gx - 5, o.getY() + gy, o.getZ() + hi + 2);
                if (level.getBlockEntity(p) != null) return false;
                if (level.getBlockState(p).getDestroySpeed(level, p) < 0) return false;
            }
        }
        return true;
    }

    // ------------------------------------------------------------- Contornos

    /** Azul = tamaño del SIGUIENTE nivel. Blanco = borde limite (siempre visible). */
    public static void showOutlines(ServerLevel level, BlockPos o, FarmKind kind, int tier) {
        ring(level, o, kind.limitSize(), ParticleTypes.END_ROD, 0.9);
        if (tier < kind.maxTier()) {
            ring(level, o, kind.size(tier + 1), ParticleTypes.SOUL_FIRE_FLAME, 0.3);
        }
    }

    private static void ring(ServerLevel level, BlockPos o, int size, ParticleOptions particle, double yOff) {
        int lo = lo(size);
        int hi = hi(size);
        double y = o.getY() + yOff;
        for (int i = lo; i <= hi; i++) {
            point(level, particle, o.getX() + i + 0.5, y, o.getZ() + lo + 0.5);
            point(level, particle, o.getX() + i + 0.5, y, o.getZ() + hi + 0.5);
            if (i > lo && i < hi) {
                point(level, particle, o.getX() + lo + 0.5, y, o.getZ() + i + 0.5);
                point(level, particle, o.getX() + hi + 0.5, y, o.getZ() + i + 0.5);
            }
        }
    }

    private static void point(ServerLevel level, ParticleOptions particle, double x, double y, double z) {
        level.sendParticles(particle, x, y, z, 1, 0.0, 0.0, 0.0, 0.0);
    }

    // ------------------------------------------------------------ Construccion

    /** Coloca hasta 'max' celdas desde 'cursor'. Devuelve el nuevo cursor. */
    public static int buildStep(ServerLevel level, BlockPos o, FarmKind kind, int tier, int cursor, int max) {
        int size = kind.size(tier);
        int lo = lo(size);
        int hi = hi(size);
        int perLayer = size * size;
        int a = tier > 1 ? BB : 0;
        int b = perLayer * LAYERS;
        int total = a + b + BB;
        int end = Math.min(total, cursor + max);
        int oldHi = tier > 1 ? hi(kind.size(tier - 1)) : 0;
        BlockState air = Blocks.AIR.defaultBlockState();
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (int i = cursor; i < end; i++) {
            if (i < a) {
                // 1) Quitar el letrero del nivel anterior
                int gx = i % BB_W;
                int gy = i / BB_W;
                p.set(o.getX() + gx - 5, o.getY() + gy, o.getZ() + oldHi + 2);
                level.setBlock(p, air, Block.UPDATE_CLIENTS);
            } else if (i < a + b) {
                // 2) Estructura: fila por fila, capa por capa hacia arriba
                int j = i - a;
                int dy = j / perLayer - 1;
                int rem = j % perLayer;
                int dx = lo + rem % size;
                int dz = lo + rem / size;
                BlockState s = stateAt(kind, tier, dx, dy, dz, lo, hi);
                if (s == null) continue;
                p.set(o.getX() + dx, o.getY() + dy, o.getZ() + dz);
                level.setBlock(p, s, s.isAir() ? Block.UPDATE_CLIENTS : Block.UPDATE_ALL);
            } else {
                // 3) Letrero de pixel art enfrente (de abajo hacia arriba)
                int j = i - a - b;
                int gx = j % BB_W;
                int gy = j / BB_W;
                p.set(o.getX() + gx - 5, o.getY() + gy, o.getZ() + hi + 2);
                level.setBlock(p, billboardState(kind, tier, gx, gy), Block.UPDATE_ALL);
            }
        }
        return end;
    }

    private static BlockState billboardState(FarmKind kind, int tier, int gx, int gy) {
        boolean frameX = gx == 0 || gx == BB_W - 1;
        boolean frameY = gy == 0 || gy == BB_H - 1;
        if (frameX || frameY) {
            if (kind.spawner && frameX && frameY) return Blocks.SEA_LANTERN.defaultBlockState();
            return pillar(tier);
        }
        String[] art = FarmArt.get(kind.theme);
        int row = (BB_H - 2) - gy; // gy = 9 -> fila 0 (arriba); gy = 1 -> fila 8 (abajo)
        int col = gx - 1;
        return FarmArt.pixel(art[row].charAt(col));
    }

    /** Que bloque va en cada posicion (null = no tocar: es el controlador). */
    public static BlockState stateAt(FarmKind kind, int tier, int dx, int dy, int dz, int lo, int hi) {
        if (dx == 0 && dy == 0 && dz == 0) return null;
        boolean mob = kind.theme.isMob();
        boolean corner = (dx == lo || dx == hi) && (dz == lo || dz == hi);
        int pillarH = mob ? TOP : 2;
        if (corner && dy >= 0 && dy < pillarH) return pillar(tier);
        if (corner && !mob && dy == pillarH) return Blocks.TORCH.defaultBlockState();
        if (corner && mob && dy == TOP + 1) return lamp(kind.theme).defaultBlockState();
        return mob ? mobState(kind, tier, dx, dy, dz, lo, hi) : resourceState(kind.theme, tier, dx, dy, dz, lo, hi);
    }

    private static BlockState pillar(int tier) {
        Block b = switch (Math.min(tier, 6)) {
            case 1 -> Blocks.CHISELED_STONE_BRICKS;
            case 2 -> Blocks.IRON_BLOCK;
            case 3 -> Blocks.GOLD_BLOCK;
            case 4 -> Blocks.DIAMOND_BLOCK;
            case 5 -> Blocks.EMERALD_BLOCK;
            default -> Blocks.NETHERITE_BLOCK;
        };
        return b.defaultBlockState();
    }

    private static BlockState wallBlock(int tier) {
        Block b = switch (Math.min(tier, 6)) {
            case 1 -> Blocks.STONE_BRICKS;
            case 2 -> Blocks.DEEPSLATE_BRICKS;
            case 3 -> Blocks.POLISHED_BLACKSTONE_BRICKS;
            case 4 -> Blocks.NETHER_BRICKS;
            case 5 -> Blocks.PRISMARINE_BRICKS;
            default -> Blocks.QUARTZ_BRICKS;
        };
        return b.defaultBlockState();
    }

    private static BlockState fence(int tier) {
        Block b = switch (Math.min(tier, 3)) {
            case 1 -> Blocks.OAK_FENCE;
            case 2 -> Blocks.NETHER_BRICK_FENCE;
            default -> Blocks.IRON_BARS;
        };
        return b.defaultBlockState();
    }

    /** Lamparas (evitan que salgan monstruos dentro). */
    private static Block lamp(FarmKind.Theme t) {
        switch (t) {
            case PIGLIN:
            case BLAZE:
            case MAGMA_CUBE:
            case GHAST:
            case WITHER_SKELETON:
                return Blocks.SHROOMLIGHT;
            default:
                return Blocks.SEA_LANTERN;
        }
    }

    /** Franja de color en las paredes, segun el tema. */
    private static Block accentBlock(FarmKind.Theme t) {
        switch (t) {
            case ZOMBIE: return Blocks.MOSS_BLOCK;
            case SKELETON: return Blocks.BONE_BLOCK;
            case SPIDER: return Blocks.BLACKSTONE;
            case CREEPER: return Blocks.GREEN_CONCRETE;
            case GOLEM: return Blocks.IRON_BLOCK;
            case PIGLIN: return Blocks.GOLD_BLOCK;
            case ENDERMAN: return Blocks.PURPUR_BLOCK;
            case WITCH: return Blocks.PURPLE_TERRACOTTA;
            case SLIME: return Blocks.SLIME_BLOCK;
            case GUARDIAN: return Blocks.PRISMARINE;
            case DROWNED: return Blocks.DARK_PRISMARINE;
            case WITHER_SKELETON: return Blocks.SOUL_SOIL;
            case COW: return Blocks.BROWN_WOOL;
            case SHEEP: return Blocks.WHITE_WOOL;
            case BLAZE: return Blocks.ORANGE_CONCRETE;
            case CAVE_SPIDER: return Blocks.CYAN_TERRACOTTA;
            case MAGMA_CUBE: return Blocks.MAGMA_BLOCK;
            case CHICKEN: return Blocks.WHITE_CONCRETE;
            case PIG: return Blocks.PINK_WOOL;
            case GHAST: return Blocks.WHITE_CONCRETE;
            default: return Blocks.STONE_BRICKS;
        }
    }

    /** Bloque del centro de la jaula (granjas de spawner). */
    private static BlockState decor(FarmKind.Theme t) {
        Block b;
        switch (t) {
            case ZOMBIE: b = Blocks.ZOMBIE_HEAD; break;
            case SKELETON: b = Blocks.SKELETON_SKULL; break;
            case CREEPER: b = Blocks.CREEPER_HEAD; break;
            case WITHER_SKELETON: b = Blocks.WITHER_SKELETON_SKULL; break;
            case GOLEM: b = Blocks.CARVED_PUMPKIN; break;
            case SPIDER:
            case CAVE_SPIDER: b = Blocks.COBWEB; break;
            case PIGLIN: b = Blocks.GOLD_BLOCK; break;
            case ENDERMAN: b = Blocks.OBSIDIAN; break;
            case WITCH: b = Blocks.CAULDRON; break;
            case SLIME: b = Blocks.SLIME_BLOCK; break;
            case GUARDIAN: b = Blocks.SEA_LANTERN; break;
            case DROWNED: b = Blocks.TUBE_CORAL_BLOCK; break;
            case COW: b = Blocks.BROWN_WOOL; break;
            case SHEEP: b = Blocks.WHITE_WOOL; break;
            case PIG: b = Blocks.PINK_WOOL; break;
            case CHICKEN: b = Blocks.HAY_BLOCK; break;
            case BLAZE: b = Blocks.SHROOMLIGHT; break;
            case MAGMA_CUBE: b = Blocks.MAGMA_BLOCK; break;
            case GHAST: b = Blocks.GLOWSTONE; break;
            default: b = Blocks.COBWEB; break;
        }
        return b.defaultBlockState();
    }

    private static BlockState resourceState(FarmKind.Theme theme, int tier, int dx, int dy, int dz, int lo, int hi) {
        BlockState air = Blocks.AIR.defaultBlockState();
        boolean center = dx == 0 && dz == 0;
        boolean edge = dx == lo || dx == hi || dz == lo || dz == hi;
        // Borde de la granja: base de ladrillo + cerca (con entrada al frente)
        if (edge) {
            if (dy == -1) return wallBlock(tier);
            if (dy == 0) {
                if (dz == hi && Math.abs(dx) <= 1) return air;
                return fence(tier);
            }
            return air;
        }
        switch (theme) {
            case SUGAR_CANE: {
                // Filas de agua cada 3: toda la arena queda pegada al agua
                boolean water = Math.floorMod(dz, 3) == 0;
                if (dy == -1) return water ? Blocks.WATER.defaultBlockState() : Blocks.SAND.defaultBlockState();
                if (dy >= 0 && dy < 3 && !water) return Blocks.SUGAR_CANE.defaultBlockState();
                return air;
            }
            case BAMBOO: {
                if (dy == -1) return Blocks.PODZOL.defaultBlockState();
                if (((dx + dz) & 1) == 0 && !center && dy >= 0 && dy < 4) {
                    BlockState s = Blocks.BAMBOO.defaultBlockState();
                    if (dy == 3) s = s.setValue(BlockStateProperties.BAMBOO_LEAVES, BambooLeaves.LARGE);
                    else if (dy == 2) s = s.setValue(BlockStateProperties.BAMBOO_LEAVES, BambooLeaves.SMALL);
                    return s;
                }
                return air;
            }
            case CACTUS: {
                if (dy == -1) return Blocks.SAND.defaultBlockState();
                if (((dx + dz) & 1) == 0 && !center && dy >= 0 && dy < 3) return Blocks.CACTUS.defaultBlockState();
                return air;
            }
            case NETHER_WART: {
                boolean path = Math.floorMod(dz, 5) == 0;
                if (dy == -1) return path ? Blocks.RED_NETHER_BRICKS.defaultBlockState() : Blocks.SOUL_SAND.defaultBlockState();
                if (dy == 0 && !path) return Blocks.NETHER_WART.defaultBlockState().setValue(BlockStateProperties.AGE_3, 3);
                return air;
            }
            case PUMPKIN:
            case MELON: {
                boolean melon = theme == FarmKind.Theme.MELON;
                boolean evenRow = (dz & 1) == 0;
                // Un agua cada 9 bloques riega todo alrededor (radio 4)
                boolean waterCell = Math.floorMod(dx, 9) == 0 && Math.floorMod(dz, 9) == 0;
                if (dy == -1) {
                    if (waterCell) return Blocks.WATER.defaultBlockState();
                    if (!evenRow) return Blocks.DIRT_PATH.defaultBlockState();
                    if ((dx & 1) != 0) {
                        return Blocks.FARMLAND.defaultBlockState().setValue(BlockStateProperties.MOISTURE, 7);
                    }
                    return Blocks.DIRT.defaultBlockState();
                }
                if (dy == 0 && evenRow && !waterCell) {
                    if ((dx & 1) != 0) {
                        return (melon ? Blocks.MELON_STEM : Blocks.PUMPKIN_STEM).defaultBlockState()
                                .setValue(BlockStateProperties.AGE_7, 7);
                    }
                    return (melon ? Blocks.MELON : Blocks.PUMPKIN).defaultBlockState();
                }
                return air;
            }
            default:
                return air;
        }
    }

    private static BlockState mobState(FarmKind kind, int tier, int dx, int dy, int dz, int lo, int hi) {
        BlockState air = Blocks.AIR.defaultBlockState();
        if (dy > TOP) return air;
        BlockState wall = wallBlock(tier);
        if (dy == -1 || dy == TOP) return wall; // suelo y techo
        boolean edge = dx == lo || dx == hi || dz == lo || dz == hi;
        if (edge) {
            if (dx == 0 && dz == hi && dy <= 1) return air; // puerta
            if (dy == 2) return accentBlock(kind.theme).defaultBlockState(); // franja de color
            return wall;
        }
        // Columnas interiores cada 8 bloques (soportan el techo y llevan una lampara arriba)
        if (Math.floorMod(dx, 8) == 0 && Math.floorMod(dz, 8) == 0 && (Math.abs(dx) > 2 || Math.abs(dz) > 4)) {
            return dy == TOP - 1 ? lamp(kind.theme).defaultBlockState() : wall;
        }
        // Jaula de barrotes con el simbolo del mob (granjas de spawner)
        if (kind.spawner && dx >= -1 && dx <= 1 && dz >= -3 && dz <= -1) {
            boolean centerCell = dx == 0 && dz == -2;
            if (dy == 0) return centerCell ? decor(kind.theme) : Blocks.IRON_BARS.defaultBlockState();
            if (dy == 1) return centerCell ? air : Blocks.IRON_BARS.defaultBlockState();
            if (dy == 2) return Blocks.IRON_BARS.defaultBlockState();
        }
        return air;
    }
}
