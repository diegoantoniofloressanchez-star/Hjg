package com.example.granjas;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;

// El id debe coincidir con mod_id en gradle.properties
@Mod(GranjasMod.MOD_ID)
public class GranjasMod {
    public static final String MOD_ID = "granjas";

    public GranjasMod(IEventBus modEventBus) {
        ModRegistry.BLOCKS.register(modEventBus);
        ModRegistry.ITEMS.register(modEventBus);
        ModRegistry.BLOCK_ENTITIES.register(modEventBus);
        ModRegistry.MENUS.register(modEventBus);
        ModRegistry.TABS.register(modEventBus);
    }
}
