package com.example.granjas;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;

/** Da el libro de guia una sola vez la primera vez que el jugador entra al mundo. */
@EventBusSubscriber(modid = GranjasMod.MOD_ID)
public class GranjasEvents {
    private static final String GIFT_TAG = "granjas_guide_given";

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        Player player = event.getEntity();
        if (player.level().isClientSide() || player.getTags().contains(GIFT_TAG)) return;
        player.addTag(GIFT_TAG);
        ItemStack book = new ItemStack(ModRegistry.GUIDE_BOOK.get());
        if (!player.getInventory().add(book)) {
            player.drop(book, false);
        }
    }
}
