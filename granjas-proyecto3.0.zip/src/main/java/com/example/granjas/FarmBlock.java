package com.example.granjas;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

/** Bloque controlador de granja. NUNCA desaparece: clic derecho abre la interfaz. */
public class FarmBlock extends Block implements EntityBlock {
    private final FarmKind kind;

    public FarmBlock(BlockBehaviour.Properties properties, FarmKind kind) {
        super(properties);
        this.kind = kind;
    }

    public FarmKind kind() {
        return kind;
    }

    /** Las granjas de mobs del Nether solo se pueden colocar en el Nether. */
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        Level level = context.getLevel();
        if (kind.requiresNether() && level.dimension() != Level.NETHER) {
            Player player = context.getPlayer();
            if (player != null && !level.isClientSide()) {
                player.displayClientMessage(
                        Component.translatable("message.granjas.nether_only").withStyle(ChatFormatting.RED), true);
            }
            return null;
        }
        return this.defaultBlockState();
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new FarmBlockEntity(pos, state);
    }

    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        if (level.isClientSide()) return null;
        return createTickerHelper(type, ModRegistry.FARM_BE.get(), FarmBlockEntity::tick);
    }

    @SuppressWarnings("unchecked")
    private static <E extends BlockEntity, A extends BlockEntity> BlockEntityTicker<A> createTickerHelper(
            BlockEntityType<A> type, BlockEntityType<E> checkedType, BlockEntityTicker<? super E> ticker) {
        return checkedType == type ? (BlockEntityTicker<A>) ticker : null;
    }

    @Override
    public InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (level.isClientSide()) return InteractionResult.SUCCESS;
        if (player instanceof ServerPlayer sp && level.getBlockEntity(pos) instanceof FarmBlockEntity be) {
            be.openMain(sp);
        }
        return InteractionResult.CONSUME;
    }
}
