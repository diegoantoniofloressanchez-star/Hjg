package com.example.granjas.client;

import com.example.granjas.GranjasMod;
import com.example.granjas.ModRegistry;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;

@EventBusSubscriber(modid = GranjasMod.MOD_ID, value = Dist.CLIENT)
public class GranjasClient {
    @SubscribeEvent
    public static void registerScreens(RegisterMenuScreensEvent event) {
        event.register(ModRegistry.FARM_MENU.get(), FarmScreen::new);
        event.register(ModRegistry.FARM_CONFIRM_MENU.get(), FarmConfirmScreen::new);
    }
}
