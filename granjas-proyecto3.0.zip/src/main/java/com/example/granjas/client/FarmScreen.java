package com.example.granjas.client;

import com.example.granjas.FarmBlockEntity;
import com.example.granjas.FarmKind;
import com.example.granjas.FarmMenu;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/** Interfaz principal: izquierda = huecos, derecha = lista de materiales (tienes / faltan). */
public class FarmScreen extends AbstractContainerScreen<FarmMenu> {
    private static final int LEFT_W = 176;
    private static final int GAP = 4;
    private static final int PANEL_W = 140;

    private Button buildButton;
    private boolean wasComplete;

    public FarmScreen(FarmMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageWidth = LEFT_W + GAP + PANEL_W;
        this.imageHeight = 208;
        this.inventoryLabelY = 114;
    }

    @Override
    protected void init() {
        super.init();
        buildButton = addRenderableWidget(Button.builder(Component.translatable("gui.granjas.build"), b -> send(0))
                .bounds(leftPos + LEFT_W + GAP + 6, topPos + 184, PANEL_W - 12, 18).build());
        wasComplete = isComplete();
        buildButton.active = wasComplete;
        buildButton.visible = menu.tier < menu.kind.maxTier();
    }

    @Override
    protected void containerTick() {
        super.containerTick();
        boolean complete = isComplete();
        if (buildButton != null) buildButton.active = complete;
        // Al completar los materiales, se abre sola la pantalla de aceptar/rechazar
        if (complete && !wasComplete) send(0);
        wasComplete = complete;
    }

    private void send(int id) {
        if (minecraft != null && minecraft.gameMode != null) {
            minecraft.gameMode.handleInventoryButtonClick(menu.containerId, id);
        }
    }

    private int have(Item item) {
        int n = 0;
        for (int i = 0; i < FarmBlockEntity.IN; i++) {
            ItemStack s = menu.slots.get(i).getItem();
            if (s.is(item)) n += s.getCount();
        }
        return n;
    }

    private boolean isComplete() {
        if (menu.tier >= menu.kind.maxTier()) return false;
        for (FarmKind.Cost c : menu.kind.cost(menu.tier + 1)) {
            if (have(c.item()) < c.count()) return false;
        }
        return true;
    }

    @Override
    protected void renderBg(GuiGraphics g, float partialTick, int mouseX, int mouseY) {
        int x = leftPos;
        int y = topPos;
        panel(g, x, y, LEFT_W, imageHeight);
        panel(g, x + LEFT_W + GAP, y, PANEL_W, imageHeight);
        for (Slot s : menu.slots) {
            int sx = x + s.x;
            int sy = y + s.y;
            g.fill(sx - 1, sy - 1, sx + 17, sy + 17, 0xFF373737);
            g.fill(sx, sy, sx + 16, sy + 16, 0xFF8B8B8B);
        }
        drawRequirements(g, x + LEFT_W + GAP, y);
    }

    private void drawRequirements(GuiGraphics g, int px, int py) {
        g.drawString(font, Component.translatable("gui.granjas.requirements"), px + 8, py + 6, 0xFF404040, false);
        if (menu.tier >= menu.kind.maxTier()) {
            int s = menu.kind.size(menu.tier);
            g.drawString(font, Component.translatable("gui.granjas.max_level"), px + 8, py + 18, 0xFF1B8A2E, false);
            g.drawString(font, Component.translatable("gui.granjas.area", s, s), px + 8, py + 30, 0xFF404040, false);
            return;
        }
        int next = menu.tier + 1;
        int size = menu.kind.size(next);
        g.drawString(font, Component.translatable("gui.granjas.upgrade", menu.tier, next), px + 8, py + 17, 0xFF305080, false);
        g.drawString(font, Component.translatable("gui.granjas.area", size, size), px + 8, py + 28, 0xFF305080, false);
        List<FarmKind.Cost> costs = menu.kind.cost(next);
        for (int i = 0; i < costs.size(); i++) {
            FarmKind.Cost c = costs.get(i);
            int ey = py + 40 + i * 18;
            int have = have(c.item());
            boolean ok = have >= c.count();
            ItemStack icon = c.icon();
            g.renderItem(icon, px + 8, ey);
            String name = font.plainSubstrByWidth(icon.getHoverName().getString(), PANEL_W - 40);
            g.drawString(font, name, px + 28, ey, 0xFF404040, false);
            g.drawString(font, Math.min(have, c.count()) + " / " + c.count(), px + 28, ey + 9, ok ? 0xFF1B8A2E : 0xFFB02020, false);
        }
        String secs = String.format(Locale.ROOT, "%.1f", menu.kind.interval(next) / 20.0);
        g.drawString(font, Component.translatable("gui.granjas.production", secs, menu.kind.multiplier(next)),
                px + 8, py + 172, 0xFF404040, false);
    }

    static void panel(GuiGraphics g, int x, int y, int w, int h) {
        g.fill(x, y, x + w, y + h, 0xFF000000);
        g.fill(x + 1, y + 1, x + w - 1, y + h - 1, 0xFFC6C6C6);
        g.fill(x + 1, y + 1, x + w - 2, y + 2, 0xFFFFFFFF);
        g.fill(x + 1, y + 1, x + 2, y + h - 2, 0xFFFFFFFF);
        g.fill(x + 2, y + h - 2, x + w - 1, y + h - 1, 0xFF555555);
        g.fill(x + w - 2, y + 2, x + w - 1, y + h - 1, 0xFF555555);
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mouseX, int mouseY) {
        super.renderLabels(g, mouseX, mouseY);
        g.drawString(font, Component.translatable("gui.granjas.materials"), 8, 18, 0xFF404040, false);
        g.drawString(font, Component.translatable("gui.granjas.output"), 8, 66, 0xFF404040, false);
    }
}
