package com.example.granjas.client;

import net.minecraft.client.Minecraft;

/** Puente para abrir pantallas solo en el cliente. */
public final class ClientHooks {
    private ClientHooks() {}

    public static void openGuide() {
        Minecraft.getInstance().setScreen(new GuideScreen());
    }
}
