package com.example.granjas.client;

import com.example.granjas.FarmArt;
import com.example.granjas.FarmKind;
import com.example.granjas.ModRegistry;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.item.ItemStack;

/**
 * Libro de guia: pagina 1 = como funciona, 2 = niveles, 3 = indice, y luego una pagina por granja
 * con su pixel art, tamaños, produccion y materiales de cada nivel (botones - y +).
 */
public class GuideScreen extends Screen {
    private static final int W = 270;
    private static final int H = 214;
    private static final int INTRO_PAGES = 3;
    private static final FarmKind[] KINDS = FarmKind.values();

    private int page = 0;
    private int tierView = 1;
    private int left;
    private int top;
    private Button prev;
    private Button next;
    private Button index;
    private Button tierDown;
    private Button tierUp;
    private Button catResource;
    private Button catNatural;
    private Button catSpawner;

    public GuideScreen() {
        super(Component.translatable("gui.granjas.guide_title"));
    }

    // ------------------------------------------------------------ categorias

    private static int category(FarmKind k) {
        if (!k.theme.isMob()) return 0;
        return k.spawner ? 2 : 1;
    }

    private static int countOf(int cat) {
        int n = 0;
        for (FarmKind k : KINDS) {
            if (category(k) == cat) n++;
        }
        return n;
    }

    private static int firstPage(int cat) {
        for (int i = 0; i < KINDS.length; i++) {
            if (category(KINDS[i]) == cat) return INTRO_PAGES + i;
        }
        return INTRO_PAGES;
    }

    private static Component catLabel(String key, int cat) {
        return Component.translatable("gui.granjas.cat_" + key).append(" (" + countOf(cat) + ")");
    }

    private int lastPage() {
        return INTRO_PAGES + KINDS.length - 1;
    }

    private FarmKind current() {
        return page >= INTRO_PAGES ? KINDS[page - INTRO_PAGES] : null;
    }

    // ------------------------------------------------------------ widgets

    @Override
    protected void init() {
        left = (width - W) / 2;
        top = (height - H) / 2;
        int by = top + H - 26;

        prev = addRenderableWidget(Button.builder(Component.literal("<"), b -> go(page - 1))
                .bounds(left + 10, by, 30, 20).build());
        index = addRenderableWidget(Button.builder(Component.translatable("gui.granjas.guide_index"), b -> go(2))
                .bounds(left + W / 2 - 45, by, 90, 20).build());
        next = addRenderableWidget(Button.builder(Component.literal(">"), b -> go(page + 1))
                .bounds(left + W - 40, by, 30, 20).build());

        tierDown = addRenderableWidget(Button.builder(Component.literal("-"), b -> changeTier(-1))
                .bounds(left + 150, top + 52, 20, 18).build());
        tierUp = addRenderableWidget(Button.builder(Component.literal("+"), b -> changeTier(1))
                .bounds(left + 174, top + 52, 20, 18).build());

        catResource = addRenderableWidget(Button.builder(catLabel("resource", 0), b -> go(firstPage(0)))
                .bounds(left + 40, top + 52, W - 80, 22).build());
        catNatural = addRenderableWidget(Button.builder(catLabel("natural", 1), b -> go(firstPage(1)))
                .bounds(left + 40, top + 82, W - 80, 22).build());
        catSpawner = addRenderableWidget(Button.builder(catLabel("spawner", 2), b -> go(firstPage(2)))
                .bounds(left + 40, top + 112, W - 80, 22).build());

        updateButtons();
    }

    private void go(int p) {
        page = Math.max(0, Math.min(lastPage(), p));
        tierView = 1;
        updateButtons();
    }

    private void changeTier(int delta) {
        FarmKind k = current();
        if (k == null) return;
        tierView = Math.max(1, Math.min(k.maxTier(), tierView + delta));
        updateButtons();
    }

    private void updateButtons() {
        prev.active = page > 0;
        next.active = page < lastPage();

        boolean onIndex = page == 2;
        catResource.visible = onIndex;
        catResource.active = onIndex;
        catNatural.visible = onIndex;
        catNatural.active = onIndex;
        catSpawner.visible = onIndex;
        catSpawner.active = onIndex;

        FarmKind k = current();
        boolean farm = k != null;
        tierDown.visible = farm;
        tierUp.visible = farm;
        tierDown.active = farm && tierView > 1;
        tierUp.active = farm && tierView < k.maxTier();
    }

    // ------------------------------------------------------------ dibujo

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.renderBackground(g, mouseX, mouseY, partialTick);
        g.fill(left - 3, top - 3, left + W + 3, top + H + 3, 0xFF2A1B0E);
        g.fill(left, top, left + W, top + H, 0xFFE2D3A2);
        g.fill(left + 4, top + 4, left + W - 4, top + H - 4, 0xFFEFE4C0);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);
        FarmKind k = current();
        if (page == 0) {
            drawText(g, "gui.granjas.guide_title", "guide.granjas.how.", 6);
        } else if (page == 1) {
            drawText(g, "guide.granjas.levels_title", "guide.granjas.lvl.", 5);
        } else if (page == 2) {
            g.drawString(font, Component.translatable("gui.granjas.guide_index"), left + 14, top + 14, 0xFF5A3A12, false);
            g.drawString(font, Component.translatable("gui.granjas.guide_hint"), left + 14, top + 32, 0xFF2B2B2B, false);
        } else {
            drawFarm(g, k);
        }
        String foot = (page + 1) + "/" + (lastPage() + 1);
        g.drawString(font, foot, left + 46, top + H - 20, 0xFF5A3A12, false);
    }

    private void drawText(GuiGraphics g, String titleKey, String prefix, int count) {
        int y = top + 12;
        g.drawString(font, Component.translatable(titleKey), left + 14, y, 0xFF5A3A12, false);
        y += 16;
        for (int i = 1; i <= count; i++) {
            for (FormattedCharSequence line : font.split(Component.translatable(prefix + i), W - 28)) {
                g.drawString(font, line, left + 14, y, 0xFF2B2B2B, false);
                y += 10;
            }
            y += 4;
        }
    }

    private void drawFarm(GuiGraphics g, FarmKind k) {
        int tx = left + 14;
        ItemStack icon = new ItemStack(ModRegistry.FARM_ITEMS.get(k).get());
        g.renderItem(icon, tx, top + 10);
        String name = font.plainSubstrByWidth(k.displayName().getString(), 170);
        g.drawString(font, name, tx + 22, top + 14, 0xFF7A4A00, false);

        String typeKey = !k.theme.isMob() ? "resource" : (k.spawner ? "spawner" : "natural");
        g.drawString(font, Component.translatable("guide.granjas.type." + typeKey), tx, top + 32, 0xFF305080, false);

        StringBuilder areas = new StringBuilder();
        for (int t = 1; t <= k.maxTier(); t++) {
            if (t > 1) areas.append(" / ");
            areas.append(k.size(t));
        }
        g.drawString(font, Component.translatable("guide.granjas.areas", areas.toString()), tx, top + 42, 0xFF2B2B2B, false);

        // Pixel art de la granja (el mismo que se construye enfrente)
        String[] art = FarmArt.get(k.theme);
        int px = left + W - 14 - 36;
        int py = top + 10;
        g.fill(px - 2, py - 2, px + 38, py + 38, 0xFF2A1B0E);
        for (int r = 0; r < 9; r++) {
            for (int c = 0; c < 9; c++) {
                g.fill(px + c * 4, py + r * 4, px + c * 4 + 4, py + r * 4 + 4, FarmArt.rgb(art[r].charAt(c)));
            }
        }

        g.drawString(font, Component.translatable("guide.granjas.tier", tierView, k.maxTier()), tx, top + 57, 0xFF5A3A12, false);
        int size = k.size(tierView);
        g.drawString(font, Component.translatable("guide.granjas.size", size, size), tx, top + 76, 0xFF2B2B2B, false);
        String secs = String.format(Locale.ROOT, "%.1f", k.interval(tierView) / 20.0);
        g.drawString(font, Component.translatable("guide.granjas.prod", secs, k.multiplier(tierView)), tx, top + 88, 0xFF2B2B2B, false);

        g.drawString(font, Component.translatable("guide.granjas.materials"), tx, top + 102, 0xFF5A3A12, false);
        if (k.requiresNether()) {
            g.drawString(font, Component.translatable("guide.granjas.nether_only"), left + 176, top + 102, 0xFFB02020, false);
        }
        List<FarmKind.Cost> costs = k.cost(tierView);
        for (int i = 0; i < costs.size(); i++) {
            FarmKind.Cost c = costs.get(i);
            int ex = tx + (i % 2) * 124;
            int ey = top + 114 + (i / 2) * 18;
            ItemStack stack = c.icon();
            g.renderItem(stack, ex, ey);
            String label = c.count() + "x " + stack.getHoverName().getString();
            g.drawString(font, font.plainSubstrByWidth(label, 100), ex + 20, ey + 4, 0xFF2B2B2B, false);
        }
    }
}
