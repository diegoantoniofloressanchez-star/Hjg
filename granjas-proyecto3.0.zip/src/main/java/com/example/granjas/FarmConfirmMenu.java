package com.example.granjas;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;

/** Segunda interfaz: ACEPTAR o RECHAZAR la construccion/mejora. Sin huecos. */
public class FarmConfirmMenu extends AbstractContainerMenu {
    public final BlockPos pos;
    public final FarmKind kind;
    public final int tier; // nivel que se va a construir
    private final FarmBlockEntity be;

    // Cliente
    public FarmConfirmMenu(int id, Inventory inv, RegistryFriendlyByteBuf buf) {
        this(id, inv, buf.readBlockPos(), FarmKind.values()[buf.readVarInt()], buf.readVarInt(), null);
    }

    // Servidor
    public FarmConfirmMenu(int id, Inventory inv, FarmBlockEntity be) {
        this(id, inv, be.getBlockPos(), be.kind(), be.tier() + 1, be);
    }

    private FarmConfirmMenu(int id, Inventory inv, BlockPos pos, FarmKind kind, int tier, FarmBlockEntity be) {
        super(ModRegistry.FARM_CONFIRM_MENU.get(), id);
        this.pos = pos;
        this.kind = kind;
        this.tier = tier;
        this.be = be;
    }

    /** 0 = aceptar (construye y consume), 1 = rechazar (vuelve al menu de materiales). */
    @Override
    public boolean clickMenuButton(Player player, int buttonId) {
        if (be == null || !(player instanceof ServerPlayer sp)) return false;
        if (buttonId == 0) {
            be.acceptBuild(sp);
            return true;
        }
        if (buttonId == 1) {
            be.openMain(sp);
            return true;
        }
        return false;
    }

    @Override
    public boolean stillValid(Player player) {
        return be == null || be.stillValid(player);
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        return ItemStack.EMPTY;
    }
}
